import jwt from 'jsonwebtoken';

// Wires up all real-time behavior. Rooms used:
//   `user:<id>`   - personal notifications for one account
//   `ride:<id>`   - everyone (passenger + driver) watching one active ride
//   `drivers`     - all currently-online drivers, used to broadcast new ride requests
export function registerSocketHandlers(io) {
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('Missing auth token'));
      socket.user = jwt.verify(token, process.env.JWT_SECRET);
      next();
    } catch (err) {
      next(new Error('Invalid auth token'));
    }
  });

  io.on('connection', (socket) => {
    const { id, role } = socket.user;
    socket.join(`user:${id}`);
    if (role === 'driver') socket.join('drivers');

    // Client joins the room for whichever ride it's currently tracking.
    socket.on('ride:join', (rideId) => {
      socket.join(`ride:${rideId}`);
    });

    socket.on('ride:leave', (rideId) => {
      socket.leave(`ride:${rideId}`);
    });

    // Driver broadcasts a location tick while on an active ride; relayed to
    // whoever is watching that ride room. (REST endpoint also persists this.)
    socket.on('driver:location', ({ rideId, lat, lng }) => {
      socket.to(`ride:${rideId}`).emit('driver:location', { lat, lng });
    });

    // In-ride chat between driver and passenger.
    socket.on('chat:message', ({ rideId, message }) => {
      io.to(`ride:${rideId}`).emit('chat:message', {
        senderId: id,
        message,
        at: new Date().toISOString(),
      });
    });

    // SOS button: notify all admins immediately.
    socket.on('sos:trigger', ({ rideId, lat, lng }) => {
      io.emit('sos:alert', { rideId, userId: id, lat, lng, at: new Date().toISOString() });
    });

    socket.on('disconnect', () => {
      // Presence cleanup could go here (e.g. mark driver offline after N seconds
      // of no heartbeat) — left as a Phase 2 enhancement.
    });
  });
}
