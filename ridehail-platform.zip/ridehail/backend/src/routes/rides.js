import express from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { calculateFare, getVehicleCatalog } from '../utils/fare.js';

const router = express.Router();

// GET /api/rides/vehicles -> static catalog used to render vehicle selection cards
router.get('/vehicles', (req, res) => {
  res.json({ vehicles: getVehicleCatalog() });
});

// POST /api/rides/estimate
// Body: { vehicleType, distanceKm, durationMin, promoCode? }
// Returns a fare breakdown for every vehicle type when vehicleType is omitted,
// or a single breakdown when it's provided (used on the final confirm step).
router.post('/estimate', requireAuth, async (req, res) => {
  try {
    const { vehicleType, distanceKm, durationMin, promoCode } = req.body;
    if (distanceKm == null || durationMin == null) {
      return res.status(400).json({ error: 'distanceKm and durationMin are required.' });
    }

    let promo = null;
    if (promoCode) {
      const promoResult = await query(
        'SELECT * FROM promo_codes WHERE code = $1 AND active = TRUE',
        [promoCode]
      );
      promo = promoResult.rows[0] || null;
      if (!promo) return res.status(400).json({ error: 'Invalid or expired promo code.' });
    }

    if (vehicleType) {
      const estimate = calculateFare({ vehicleType, distanceKm, durationMin, promo });
      return res.json({ estimate });
    }

    const catalog = getVehicleCatalog();
    const estimates = catalog.map((v) =>
      calculateFare({ vehicleType: v.type, distanceKm, durationMin, promo })
    );
    res.json({ estimates });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// POST /api/rides -> passenger requests a ride
router.post('/', requireAuth, requireRole('passenger'), async (req, res) => {
  try {
    const {
      vehicleType, pickupAddress, pickupLat, pickupLng,
      destinationAddress, destinationLat, destinationLng,
      distanceKm, durationMin, paymentMethod = 'cash', promoCode,
    } = req.body;

    if (!vehicleType || !pickupAddress || !destinationAddress || pickupLat == null || destinationLat == null) {
      return res.status(400).json({ error: 'Missing required ride details.' });
    }

    let promo = null;
    if (promoCode) {
      const promoResult = await query('SELECT * FROM promo_codes WHERE code = $1 AND active = TRUE', [promoCode]);
      promo = promoResult.rows[0] || null;
    }

    const fare = calculateFare({ vehicleType, distanceKm, durationMin, promo });

    const result = await query(
      `INSERT INTO rides (
         passenger_id, vehicle_type, pickup_address, pickup_lat, pickup_lng,
         destination_address, destination_lat, destination_lng,
         distance_km, duration_min, fare_breakdown, fare_total, payment_method, ride_status
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'requested')
       RETURNING *`,
      [
        req.user.id, vehicleType, pickupAddress, pickupLat, pickupLng,
        destinationAddress, destinationLat, destinationLng,
        distanceKm, durationMin, JSON.stringify(fare.breakdown), fare.total, paymentMethod,
      ]
    );

    const ride = result.rows[0];

    // Find nearby online, approved drivers of the matching vehicle type.
    // Simple nearest-first match by straight-line distance (good enough for a demo;
    // swap for PostGIS ST_DWithin in production).
    const candidates = await query(
      `SELECT d.*, u.name, u.phone FROM drivers d
       JOIN users u ON u.id = d.user_id
       WHERE d.status = 'online' AND d.approval_status = 'approved' AND d.vehicle_type = $1
       AND d.current_lat IS NOT NULL`,
      [vehicleType]
    );

    const nearest = candidates.rows
      .map((d) => ({ ...d, dist: haversine(pickupLat, pickupLng, d.current_lat, d.current_lng) }))
      .sort((a, b) => a.dist - b.dist)
      .slice(0, 5); // notify up to 5 nearest drivers

    // Real-time dispatch happens via Socket.IO (see sockets/index.js), which
    // listens for this event through the shared `io` instance attached to the app.
    req.app.get('io')?.to('drivers').emit('ride:new-request', {
      ride,
      candidateDriverIds: nearest.map((d) => d.user_id),
    });

    res.status(201).json({ ride, notifiedDrivers: nearest.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create ride request.' });
  }
});

// GET /api/rides/mine -> ride history for the logged-in passenger or driver
router.get('/mine', requireAuth, async (req, res) => {
  const { status, search } = req.query;
  let sql, params;

  if (req.user.role === 'driver') {
    const driverRow = await query('SELECT id FROM drivers WHERE user_id = $1', [req.user.id]);
    const driverId = driverRow.rows[0]?.id;
    sql = `SELECT r.*, u.name AS passenger_name, u.phone AS passenger_phone
           FROM rides r JOIN users u ON u.id = r.passenger_id
           WHERE r.driver_id = $1`;
    params = [driverId];
  } else {
    sql = `SELECT r.*, du.name AS driver_name, d.vehicle_number
           FROM rides r
           LEFT JOIN drivers d ON d.id = r.driver_id
           LEFT JOIN users du ON du.id = d.user_id
           WHERE r.passenger_id = $1`;
    params = [req.user.id];
  }

  if (status) {
    sql += ` AND r.ride_status = $${params.length + 1}`;
    params.push(status);
  }
  if (search) {
    sql += ` AND (r.pickup_address ILIKE $${params.length + 1} OR r.destination_address ILIKE $${params.length + 1})`;
    params.push(`%${search}%`);
  }
  sql += ' ORDER BY r.created_at DESC LIMIT 100';

  const result = await query(sql, params);
  res.json({ rides: result.rows });
});

// GET /api/rides/active -> the passenger's or driver's current in-progress ride, if any
router.get('/active', requireAuth, async (req, res) => {
  const activeStatuses = ['requested', 'accepted', 'arriving', 'arrived', 'ongoing'];
  let sql, params;
  if (req.user.role === 'driver') {
    const driverRow = await query('SELECT id FROM drivers WHERE user_id = $1', [req.user.id]);
    sql = `SELECT * FROM rides WHERE driver_id = $1 AND ride_status = ANY($2) ORDER BY created_at DESC LIMIT 1`;
    params = [driverRow.rows[0]?.id, activeStatuses];
  } else {
    sql = `SELECT * FROM rides WHERE passenger_id = $1 AND ride_status = ANY($2) ORDER BY created_at DESC LIMIT 1`;
    params = [req.user.id, activeStatuses];
  }
  const result = await query(sql, params);
  res.json({ ride: result.rows[0] || null });
});

// PUT /api/rides/:id/accept -> driver accepts a pending request
router.put('/:id/accept', requireAuth, requireRole('driver'), async (req, res) => {
  const driverRow = await query('SELECT * FROM drivers WHERE user_id = $1', [req.user.id]);
  const driver = driverRow.rows[0];
  if (!driver) return res.status(404).json({ error: 'Driver profile not found.' });

  const result = await query(
    `UPDATE rides SET driver_id = $1, ride_status = 'accepted', updated_at = now()
     WHERE id = $2 AND ride_status = 'requested' RETURNING *`,
    [driver.id, req.params.id]
  );
  if (!result.rows.length) {
    return res.status(409).json({ error: 'This ride was already accepted by another driver.' });
  }
  await query(`UPDATE drivers SET status = 'on_trip' WHERE id = $1`, [driver.id]);

  const ride = result.rows[0];
  req.app.get('io')?.to(`ride:${ride.id}`).emit('ride:updated', ride);
  req.app.get('io')?.to(`user:${ride.passenger_id}`).emit('ride:updated', ride);
  res.json({ ride });
});

// PUT /api/rides/:id/status -> generic status transitions driven by the driver
// Valid next statuses: arriving, arrived, ongoing, completed, cancelled
router.put('/:id/status', requireAuth, async (req, res) => {
  const { status } = req.body;
  const allowed = ['arriving', 'arrived', 'ongoing', 'completed', 'cancelled'];
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status.' });

  const result = await query(
    `UPDATE rides SET ride_status = $1, updated_at = now() WHERE id = $2 RETURNING *`,
    [status, req.params.id]
  );
  const ride = result.rows[0];
  if (!ride) return res.status(404).json({ error: 'Ride not found.' });

  if (status === 'completed') {
    await query(
      `INSERT INTO payments (ride_id, amount, payment_status, payment_method) VALUES ($1,$2,'paid',$3)`,
      [ride.id, ride.fare_total, ride.payment_method]
    );
    await query(`UPDATE rides SET payment_status = 'paid' WHERE id = $1`, [ride.id]);
    if (ride.driver_id) {
      await query(
        `UPDATE drivers SET status = 'online', total_trips = total_trips + 1 WHERE id = $1`,
        [ride.driver_id]
      );
    }
    if (ride.payment_method === 'wallet') {
      await query('UPDATE users SET wallet_balance = wallet_balance - $1 WHERE id = $2', [
        ride.fare_total, ride.passenger_id,
      ]);
    }
  }

  if (status === 'cancelled' && ride.driver_id) {
    await query(`UPDATE drivers SET status = 'online' WHERE id = $1`, [ride.driver_id]);
  }

  req.app.get('io')?.to(`ride:${ride.id}`).emit('ride:updated', ride);
  req.app.get('io')?.to(`user:${ride.passenger_id}`).emit('ride:updated', ride);
  res.json({ ride });
});

// POST /api/rides/:id/review -> passenger rates driver (or vice versa)
router.post('/:id/review', requireAuth, async (req, res) => {
  const { rating, review, direction } = req.body; // direction: 'to_driver' | 'to_passenger'
  const rideResult = await query('SELECT * FROM rides WHERE id = $1', [req.params.id]);
  const ride = rideResult.rows[0];
  if (!ride) return res.status(404).json({ error: 'Ride not found.' });

  const col = direction === 'to_passenger' ? 'rating_of_passenger' : 'rating_of_driver';
  await query(
    `INSERT INTO reviews (ride_id, passenger_id, driver_id, ${col}, review)
     VALUES ($1,$2,$3,$4,$5)`,
    [ride.id, ride.passenger_id, ride.driver_id, rating, review || null]
  );

  if (direction !== 'to_passenger' && ride.driver_id) {
    const avgResult = await query(
      'SELECT AVG(rating_of_driver) AS avg FROM reviews WHERE driver_id = $1 AND rating_of_driver IS NOT NULL',
      [ride.driver_id]
    );
    await query('UPDATE drivers SET rating_avg = $1 WHERE id = $2', [
      Number(avgResult.rows[0].avg).toFixed(1), ride.driver_id,
    ]);
  }

  res.status(201).json({ message: 'Review submitted.' });
});

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export default router;
