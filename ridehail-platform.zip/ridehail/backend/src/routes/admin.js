import express from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = express.Router();
router.use(requireAuth, requireRole('admin'));

// GET /api/admin/overview -> headline stats for the dashboard
router.get('/overview', async (req, res) => {
  const [users, drivers, activeDrivers, trips, revenue] = await Promise.all([
    query(`SELECT COUNT(*) FROM users WHERE role = 'passenger'`),
    query(`SELECT COUNT(*) FROM drivers`),
    query(`SELECT COUNT(*) FROM drivers WHERE status = 'online'`),
    query(`SELECT COUNT(*) FROM rides WHERE ride_status = 'completed'`),
    query(`SELECT COALESCE(SUM(fare_total),0) AS total FROM rides WHERE ride_status = 'completed'`),
  ]);

  const dailyRevenue = await query(`
    SELECT to_char(created_at, 'Mon DD') AS day, SUM(fare_total) AS total
    FROM rides WHERE ride_status = 'completed' AND created_at >= CURRENT_DATE - INTERVAL '14 days'
    GROUP BY day, date_trunc('day', created_at) ORDER BY date_trunc('day', created_at)
  `);

  res.json({
    totalUsers: Number(users.rows[0].count),
    totalDrivers: Number(drivers.rows[0].count),
    activeDrivers: Number(activeDrivers.rows[0].count),
    totalTrips: Number(trips.rows[0].count),
    totalRevenue: Number(revenue.rows[0].total),
    revenueChart: dailyRevenue.rows.map((r) => ({ day: r.day, total: Number(r.total) })),
  });
});

// GET /api/admin/users -> user management list
router.get('/users', async (req, res) => {
  const result = await query(
    `SELECT id, name, email, phone, role, is_verified, wallet_balance, created_at
     FROM users ORDER BY created_at DESC LIMIT 200`
  );
  res.json({ users: result.rows });
});

// PUT /api/admin/users/:id/suspend -> demo suspension flag lives on is_verified
router.put('/users/:id/suspend', async (req, res) => {
  await query('UPDATE users SET is_verified = FALSE WHERE id = $1', [req.params.id]);
  res.json({ message: 'User suspended.' });
});

// GET /api/admin/drivers -> driver approval queue + roster
router.get('/drivers', async (req, res) => {
  const { approval_status } = req.query;
  let sql = `SELECT d.*, u.name, u.email, u.phone FROM drivers d JOIN users u ON u.id = d.user_id`;
  const params = [];
  if (approval_status) {
    sql += ' WHERE d.approval_status = $1';
    params.push(approval_status);
  }
  sql += ' ORDER BY d.created_at DESC';
  const result = await query(sql, params);
  res.json({ drivers: result.rows });
});

// PUT /api/admin/drivers/:id/approval
router.put('/drivers/:id/approval', async (req, res) => {
  const { approval_status } = req.body; // 'approved' | 'rejected'
  if (!['approved', 'rejected'].includes(approval_status)) {
    return res.status(400).json({ error: 'Invalid approval status.' });
  }
  const result = await query(
    'UPDATE drivers SET approval_status = $1 WHERE id = $2 RETURNING *',
    [approval_status, req.params.id]
  );
  res.json({ driver: result.rows[0] });
});

// GET /api/admin/rides -> ride monitoring feed
router.get('/rides', async (req, res) => {
  const { status } = req.query;
  let sql = `SELECT r.*, pu.name AS passenger_name, du.name AS driver_name
             FROM rides r
             JOIN users pu ON pu.id = r.passenger_id
             LEFT JOIN drivers d ON d.id = r.driver_id
             LEFT JOIN users du ON du.id = d.user_id`;
  const params = [];
  if (status) {
    sql += ' WHERE r.ride_status = $1';
    params.push(status);
  }
  sql += ' ORDER BY r.created_at DESC LIMIT 200';
  const result = await query(sql, params);
  res.json({ rides: result.rows });
});

// GET /api/admin/feedback -> reviews with low ratings surfaced first
router.get('/feedback', async (req, res) => {
  const result = await query(
    `SELECT rv.*, pu.name AS passenger_name, du.name AS driver_name
     FROM reviews rv
     JOIN users pu ON pu.id = rv.passenger_id
     LEFT JOIN drivers d ON d.id = rv.driver_id
     LEFT JOIN users du ON du.id = d.user_id
     ORDER BY rv.created_at DESC LIMIT 200`
  );
  res.json({ feedback: result.rows });
});

// Promo code management
router.get('/promo-codes', async (req, res) => {
  const result = await query('SELECT * FROM promo_codes ORDER BY id DESC');
  res.json({ promoCodes: result.rows });
});

router.post('/promo-codes', async (req, res) => {
  const { code, discountPercent, discountFlat, maxUses, expiresAt } = req.body;
  const result = await query(
    `INSERT INTO promo_codes (code, discount_percent, discount_flat, max_uses, expires_at)
     VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [code, discountPercent || null, discountFlat || null, maxUses || null, expiresAt || null]
  );
  res.status(201).json({ promoCode: result.rows[0] });
});

router.put('/promo-codes/:id/toggle', async (req, res) => {
  const result = await query(
    'UPDATE promo_codes SET active = NOT active WHERE id = $1 RETURNING *',
    [req.params.id]
  );
  res.json({ promoCode: result.rows[0] });
});

export default router;
