import express from 'express';
import { query } from '../config/db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = express.Router();

// GET /api/drivers/me -> driver profile + vehicle info
router.get('/me', requireAuth, requireRole('driver'), async (req, res) => {
  const result = await query(
    `SELECT d.*, u.name, u.email, u.phone, u.profile_photo, u.wallet_balance
     FROM drivers d JOIN users u ON u.id = d.user_id WHERE d.user_id = $1`,
    [req.user.id]
  );
  res.json({ driver: result.rows[0] });
});

// PUT /api/drivers/me -> update vehicle info / documents
router.put('/me', requireAuth, requireRole('driver'), async (req, res) => {
  const { vehicleType, vehicleNumber, drivingLicense, licenseDocUrl } = req.body;
  const result = await query(
    `UPDATE drivers SET
       vehicle_type = COALESCE($1, vehicle_type),
       vehicle_number = COALESCE($2, vehicle_number),
       driving_license = COALESCE($3, driving_license),
       license_doc_url = COALESCE($4, license_doc_url)
     WHERE user_id = $5 RETURNING *`,
    [vehicleType, vehicleNumber, drivingLicense, licenseDocUrl, req.user.id]
  );
  res.json({ driver: result.rows[0] });
});

// PUT /api/drivers/status -> toggle online/offline
router.put('/status', requireAuth, requireRole('driver'), async (req, res) => {
  const { status } = req.body; // 'online' | 'offline'
  if (!['online', 'offline'].includes(status)) {
    return res.status(400).json({ error: 'status must be online or offline.' });
  }
  const result = await query(
    'UPDATE drivers SET status = $1 WHERE user_id = $2 RETURNING *',
    [status, req.user.id]
  );
  res.json({ driver: result.rows[0] });
});

// PUT /api/drivers/location -> live location ping (also broadcast over sockets)
router.put('/location', requireAuth, requireRole('driver'), async (req, res) => {
  const { lat, lng } = req.body;
  const result = await query(
    'UPDATE drivers SET current_lat = $1, current_lng = $2 WHERE user_id = $3 RETURNING id',
    [lat, lng, req.user.id]
  );
  const driver = result.rows[0];

  // Let anyone tracking this driver's active ride see the movement live.
  const activeRide = await query(
    `SELECT id, passenger_id FROM rides WHERE driver_id = $1
     AND ride_status IN ('accepted','arriving','arrived','ongoing') LIMIT 1`,
    [driver.id]
  );
  if (activeRide.rows.length) {
    req.app.get('io')?.to(`ride:${activeRide.rows[0].id}`).emit('driver:location', { lat, lng });
  }
  res.json({ message: 'Location updated.' });
});

// GET /api/drivers/earnings -> today + weekly earnings summary
router.get('/earnings', requireAuth, requireRole('driver'), async (req, res) => {
  const driverRow = await query('SELECT id FROM drivers WHERE user_id = $1', [req.user.id]);
  const driverId = driverRow.rows[0]?.id;

  const today = await query(
    `SELECT COALESCE(SUM(fare_total),0) AS total, COUNT(*) AS trips FROM rides
     WHERE driver_id = $1 AND ride_status = 'completed' AND created_at::date = CURRENT_DATE`,
    [driverId]
  );

  const weekly = await query(
    `SELECT to_char(created_at, 'Dy') AS day, SUM(fare_total) AS total
     FROM rides WHERE driver_id = $1 AND ride_status = 'completed'
       AND created_at >= CURRENT_DATE - INTERVAL '7 days'
     GROUP BY day, date_trunc('day', created_at) ORDER BY date_trunc('day', created_at)`,
    [driverId]
  );

  res.json({
    today: { total: Number(today.rows[0].total), trips: Number(today.rows[0].trips) },
    weekly: weekly.rows.map((r) => ({ day: r.day, total: Number(r.total) })),
  });
});

export default router;
