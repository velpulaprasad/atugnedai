import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from '../config/db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

function signToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role, email: user.email, name: user.name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

function publicUser(u) {
  const { password_hash, ...safe } = u;
  return safe;
}

// POST /api/auth/signup
router.post('/signup', async (req, res) => {
  try {
    const { name, email, password, phone, role = 'passenger' } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required.' });
    }
    if (!['passenger', 'driver'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role for signup.' });
    }

    const existing = await query('SELECT id FROM users WHERE email = $1', [email]);
    if (existing.rows.length) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const result = await query(
      `INSERT INTO users (name, email, phone, password_hash, role)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [name, email, phone || null, passwordHash, role]
    );
    const user = result.rows[0];

    // Driver accounts also get a row in `drivers`, pending admin approval.
    if (role === 'driver') {
      await query(
        `INSERT INTO drivers (user_id, vehicle_type, approval_status, status)
         VALUES ($1, 'mini', 'pending', 'offline')`,
        [user.id]
      );
    }

    // Simulated email verification: in production this would send a real email.
    // For this demo, accounts are marked verified immediately.
    await query('UPDATE users SET is_verified = TRUE WHERE id = $1', [user.id]);

    const token = signToken(user);
    res.status(201).json({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Signup failed.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const result = await query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];
    if (!user) return res.status(401).json({ error: 'Invalid email or password.' });

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.status(401).json({ error: 'Invalid email or password.' });

    const token = signToken(user);
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed.' });
  }
});

// POST /api/auth/forgot-password
// Demo implementation: generates a reset token and returns it directly instead
// of emailing it, since no email provider is wired up in this starter.
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    const result = await query('SELECT id FROM users WHERE email = $1', [email]);
    if (!result.rows.length) {
      // Don't reveal whether the email exists.
      return res.json({ message: 'If that email exists, a reset link has been sent.' });
    }
    const resetToken = jwt.sign({ id: result.rows[0].id, purpose: 'reset' }, process.env.JWT_SECRET, {
      expiresIn: '15m',
    });
    res.json({
      message: 'Reset token generated (demo mode — no email provider configured).',
      resetToken,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not process password reset.' });
  }
});

// POST /api/auth/reset-password
router.post('/reset-password', async (req, res) => {
  try {
    const { resetToken, newPassword } = req.body;
    const payload = jwt.verify(resetToken, process.env.JWT_SECRET);
    if (payload.purpose !== 'reset') throw new Error('Invalid token purpose');

    const passwordHash = await bcrypt.hash(newPassword, 10);
    await query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, payload.id]);
    res.json({ message: 'Password updated successfully.' });
  } catch (err) {
    res.status(400).json({ error: 'Reset link is invalid or expired.' });
  }
});

// GET /api/auth/me
router.get('/me', requireAuth, async (req, res) => {
  const result = await query('SELECT * FROM users WHERE id = $1', [req.user.id]);
  if (!result.rows.length) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: publicUser(result.rows[0]) });
});

export default router;
