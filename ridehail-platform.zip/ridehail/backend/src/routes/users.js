import express from 'express';
import { query } from '../config/db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// GET /api/users/profile
router.get('/profile', requireAuth, async (req, res) => {
  const result = await query(
    'SELECT id, name, email, phone, profile_photo, wallet_balance, role, created_at FROM users WHERE id = $1',
    [req.user.id]
  );
  res.json({ user: result.rows[0] });
});

// PUT /api/users/profile
router.put('/profile', requireAuth, async (req, res) => {
  const { name, phone, profile_photo } = req.body;
  const result = await query(
    `UPDATE users SET name = COALESCE($1, name), phone = COALESCE($2, phone),
       profile_photo = COALESCE($3, profile_photo)
     WHERE id = $4 RETURNING id, name, email, phone, profile_photo, wallet_balance, role`,
    [name, phone, profile_photo, req.user.id]
  );
  res.json({ user: result.rows[0] });
});

// GET /api/users/addresses
router.get('/addresses', requireAuth, async (req, res) => {
  const result = await query(
    'SELECT * FROM saved_addresses WHERE user_id = $1 ORDER BY created_at DESC',
    [req.user.id]
  );
  res.json({ addresses: result.rows });
});

// POST /api/users/addresses
router.post('/addresses', requireAuth, async (req, res) => {
  const { label, address, lat, lng } = req.body;
  if (!label || !address || lat == null || lng == null) {
    return res.status(400).json({ error: 'label, address, lat and lng are required.' });
  }
  const result = await query(
    `INSERT INTO saved_addresses (user_id, label, address, lat, lng)
     VALUES ($1, $2, $3, $4, $5) RETURNING *`,
    [req.user.id, label, address, lat, lng]
  );
  res.status(201).json({ address: result.rows[0] });
});

// DELETE /api/users/addresses/:id
router.delete('/addresses/:id', requireAuth, async (req, res) => {
  await query('DELETE FROM saved_addresses WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
  res.json({ message: 'Address removed.' });
});

// GET /api/users/notifications
router.get('/notifications', requireAuth, async (req, res) => {
  const result = await query(
    'SELECT * FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
    [req.user.id]
  );
  res.json({ notifications: result.rows });
});

// PUT /api/users/notifications/:id/read
router.put('/notifications/:id/read', requireAuth, async (req, res) => {
  await query('UPDATE notifications SET is_read = TRUE WHERE id = $1 AND user_id = $2', [
    req.params.id,
    req.user.id,
  ]);
  res.json({ message: 'Marked as read.' });
});

export default router;
