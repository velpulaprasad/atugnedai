// Fare engine: transparent, rule-based pricing so the frontend can show a
// full breakdown before the rider books.

const VEHICLE_RATES = {
  bike:    { base: 15, perKm: 6,  perMin: 0.8, capacity: 1 },
  auto:    { base: 25, perKm: 9,  perMin: 1.0, capacity: 3 },
  mini:    { base: 40, perKm: 11, perMin: 1.2, capacity: 4 },
  sedan:   { base: 55, perKm: 14, perMin: 1.5, capacity: 4 },
  suv:     { base: 80, perKm: 18, perMin: 1.8, capacity: 6 },
  premium: { base: 120, perKm: 24, perMin: 2.2, capacity: 4 },
  ev:      { base: 45, perKm: 10, perMin: 1.1, capacity: 4 },
};

const TAX_RATE = 0.05; // 5% government tax, shown as its own line item

export function getVehicleCatalog() {
  return Object.entries(VEHICLE_RATES).map(([type, r]) => ({
    type,
    base: r.base,
    perKm: r.perKm,
    perMin: r.perMin,
    capacity: r.capacity,
  }));
}

function isPeakHour(date) {
  const h = date.getHours();
  return (h >= 8 && h < 10) || (h >= 17 && h < 20);
}

function isNightHour(date) {
  const h = date.getHours();
  return h >= 22 || h < 5;
}

// distanceKm and durationMin come from the route the client draws with
// Leaflet (haversine + an assumed average speed, see frontend/src/utils/geo.js).
export function calculateFare({ vehicleType, distanceKm, durationMin, promo = null, at = new Date() }) {
  const rate = VEHICLE_RATES[vehicleType];
  if (!rate) throw new Error(`Unknown vehicle type: ${vehicleType}`);

  const baseFare = rate.base;
  const distancePrice = round(rate.perKm * distanceKm);
  const timePrice = round(rate.perMin * durationMin);

  const peakCharge = isPeakHour(at) ? round((baseFare + distancePrice) * 0.15) : 0;
  const nightCharge = isNightHour(at) ? round((baseFare + distancePrice) * 0.10) : 0;

  const subtotal = baseFare + distancePrice + timePrice + peakCharge + nightCharge;
  const tax = round(subtotal * TAX_RATE);

  let discount = 0;
  if (promo) {
    if (promo.discount_percent) discount = round(subtotal * (promo.discount_percent / 100));
    if (promo.discount_flat) discount = Math.max(discount, Number(promo.discount_flat));
    discount = Math.min(discount, subtotal);
  }

  const total = round(subtotal + tax - discount);

  return {
    vehicleType,
    distanceKm: round(distanceKm),
    durationMin: round(durationMin),
    breakdown: { baseFare, distancePrice, timePrice, peakCharge, nightCharge, tax, discount },
    total,
  };
}

function round(n) {
  return Math.round(n * 100) / 100;
}
