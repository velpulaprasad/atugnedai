// Seeds the database with demo users, drivers, and a sample ride so the app
// is immediately explorable after setup. Run with: npm run seed
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { pool, query } from './config/db.js';

dotenv.config();

async function seed() {
  console.log('Seeding database...');
  const pw = await bcrypt.hash('password123', 10);

  // --- Admin ---
  const admin = await upsertUser('Ava Patel', 'admin@ridehail.dev', pw, 'admin');

  // --- Passengers ---
  const p1 = await upsertUser('Riya Shah', 'riya@example.com', pw, 'passenger');
  const p2 = await upsertUser('Karan Mehta', 'karan@example.com', pw, 'passenger');

  // --- Drivers ---
  const d1u = await upsertUser('Sanjay Verma', 'sanjay.driver@example.com', pw, 'driver');
  const d2u = await upsertUser('Meera Nair', 'meera.driver@example.com', pw, 'driver');

  const d1 = await upsertDriver(d1u.id, {
    vehicleType: 'sedan', vehicleNumber: 'GJ01AB1234', license: 'DL-99881122',
    lat: 23.0225, lng: 72.5714, status: 'online', approval: 'approved',
  });
  const d2 = await upsertDriver(d2u.id, {
    vehicleType: 'mini', vehicleNumber: 'GJ01CD5678', license: 'DL-77665544',
    lat: 23.0325, lng: 72.5814, status: 'online', approval: 'approved',
  });

  // A third driver still pending approval, to populate the admin queue.
  const d3u = await upsertUser('Tarun Joshi', 'tarun.driver@example.com', pw, 'driver');
  await upsertDriver(d3u.id, {
    vehicleType: 'auto', vehicleNumber: 'GJ01EF9012', license: 'DL-55443322',
    lat: 23.01, lng: 72.55, status: 'offline', approval: 'pending',
  });

  // --- Promo code ---
  await query(
    `INSERT INTO promo_codes (code, discount_percent, max_uses)
     VALUES ('WELCOME20', 20, 100) ON CONFLICT (code) DO NOTHING`
  );

  // --- Sample completed ride ---
  await query(
    `INSERT INTO rides (
       passenger_id, driver_id, vehicle_type, pickup_address, pickup_lat, pickup_lng,
       destination_address, destination_lat, destination_lng, distance_km, duration_min,
       fare_breakdown, fare_total, payment_method, payment_status, ride_status
     ) VALUES ($1,$2,'sedan','MG Road, Ahmedabad',23.0225,72.5714,
       'SG Highway, Ahmedabad',23.0395,72.5066, 8.4, 22,
       '{"baseFare":55,"distancePrice":92.4,"timePrice":33,"peakCharge":0,"nightCharge":0,"tax":9.02,"discount":0}',
       189.42, 'card', 'paid', 'completed')`,
    [p1.id, d1.id]
  );

  console.log('Seed complete. Demo login (all roles) password: password123');
  console.log(`  Admin:     admin@ridehail.dev`);
  console.log(`  Passenger: riya@example.com`);
  console.log(`  Driver:    sanjay.driver@example.com`);

  await pool.end();
}

async function upsertUser(name, email, passwordHash, role) {
  const existing = await query('SELECT * FROM users WHERE email = $1', [email]);
  if (existing.rows.length) return existing.rows[0];
  const result = await query(
    `INSERT INTO users (name, email, password_hash, role, is_verified) VALUES ($1,$2,$3,$4,TRUE) RETURNING *`,
    [name, email, passwordHash, role]
  );
  return result.rows[0];
}

async function upsertDriver(userId, { vehicleType, vehicleNumber, license, lat, lng, status, approval }) {
  const existing = await query('SELECT * FROM drivers WHERE user_id = $1', [userId]);
  if (existing.rows.length) return existing.rows[0];
  const result = await query(
    `INSERT INTO drivers (user_id, vehicle_type, vehicle_number, driving_license, current_lat, current_lng, status, approval_status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [userId, vehicleType, vehicleNumber, license, lat, lng, status, approval]
  );
  return result.rows[0];
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
