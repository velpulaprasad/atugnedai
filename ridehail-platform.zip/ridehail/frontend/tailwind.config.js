/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        ink: '#0B0F14',        // near-black background, "night city" base
        dusk: '#141B23',       // elevated dark surface
        paper: '#F6F4EF',      // light surface
        mist: '#EAE7DE',       // light elevated surface
        signal: '#FFB020',     // amber — taxi-light accent, primary CTA
        transit: '#12867F',    // teal — routes, secondary actions
        coral: '#FF5A5F',      // alerts, SOS, cancellations
        slate: {
          400: '#8B95A1',
          600: '#4B5563',
          800: '#1F2937',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      boxShadow: {
        soft: '0 8px 30px rgba(11, 15, 20, 0.08)',
        glow: '0 0 0 1px rgba(255,176,32,0.35), 0 8px 24px rgba(255,176,32,0.18)',
      },
    },
  },
  plugins: [],
};
