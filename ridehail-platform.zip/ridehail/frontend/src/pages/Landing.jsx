import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../components/Toast';

const SERVICES = [
  { emoji: '🏍️', title: 'Bike', desc: 'Split traffic, arrive fast. Best for solo trips under 5 km.' },
  { emoji: '🛺', title: 'Auto', desc: 'Open-air, budget-friendly rides for short city hops.' },
  { emoji: '🚗', title: 'Mini & Sedan', desc: 'Comfortable everyday rides with AC, up to 4 seats.' },
  { emoji: '🚐', title: 'SUV', desc: 'Extra room for groups, luggage, or airport runs.' },
  { emoji: '🚘', title: 'Premium', desc: 'Top-rated drivers, newer cars, priority pickup.' },
  { emoji: '⚡', title: 'Electric', desc: 'Zero tailpipe emissions, same fast dispatch.' },
];

const WHY = [
  { title: 'Upfront fares', desc: 'See the full breakdown — base, distance, time, taxes — before you book. No surprises at drop-off.' },
  { title: 'Live everything', desc: 'Track your driver on the map from the moment they accept, down to the meter.' },
  { title: 'Verified drivers', desc: 'Every driver is document-checked and approved before they can go online.' },
];

const TESTIMONIALS = [
  { name: 'Priya K.', quote: 'The fare breakdown before booking is the reason I switched. No more guessing games.', role: 'Rider, 3 years' },
  { name: 'Amit D.', quote: 'Driving here, the earnings dashboard actually tells me something useful about my week.', role: 'Driver, 1.5 years' },
  { name: 'Neha S.', quote: 'Booked a ride for my parents from another city — the live tracking gave me real peace of mind.', role: 'Rider, 8 months' },
];

const FAQS = [
  { q: 'How is the fare calculated?', a: 'Base fare plus a per-kilometer and per-minute rate for your vehicle type, with transparent peak-hour and night surcharges, tax, and any discount applied. The full breakdown shows before you confirm.' },
  { q: 'How do I become a driver?', a: 'Sign up choosing "Drive," add your vehicle and license details, and upload your documents. An admin reviews and approves your account, usually within a day.' },
  { q: 'What payment methods are supported?', a: 'Cash, card, UPI, and in-app wallet. All non-cash methods are simulated in this demo — no real charges occur.' },
  { q: 'Can I schedule a ride in advance?', a: 'Yes — pick a future pickup time on the booking screen and a driver will be matched closer to departure.' },
];

export default function Landing() {
  const [pickup, setPickup] = useState('');
  const [dest, setDest] = useState('');
  const [contactForm, setContactForm] = useState({ name: '', email: '', message: '' });
  const navigate = useNavigate();
  const { push } = useToast();

  function handleSearch(e) {
    e.preventDefault();
    navigate('/signup');
  }

  function handleContact(e) {
    e.preventDefault();
    push("Thanks — we'll get back to you shortly.", 'success');
    setContactForm({ name: '', email: '', message: '' });
  }

  return (
    <div className="bg-paper">
      {/* HERO */}
      <section className="relative bg-ink text-paper overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: 'radial-gradient(circle at 20% 20%, #FFB020 0%, transparent 35%), radial-gradient(circle at 80% 60%, #12867F 0%, transparent 40%)'
        }} />
        <div className="relative max-w-7xl mx-auto px-6 pt-20 pb-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="font-mono text-signal text-sm tracking-widest mb-4">METER RUNNING · CITY-WIDE</p>
            <h1 className="font-display text-5xl md:text-6xl font-bold leading-[1.05] mb-6">
              Go anywhere,<br /> the fare shown <span className="text-signal">up front.</span>
            </h1>
            <p className="text-paper/70 text-lg max-w-md mb-8">
              Book a ride in seconds. Watch your driver approach on the map, and know the full cost before you tap confirm.
            </p>

            <form onSubmit={handleSearch} className="card p-4 flex flex-col sm:flex-row gap-3">
              <input
                className="input flex-1" placeholder="Pickup location"
                value={pickup} onChange={(e) => setPickup(e.target.value)}
              />
              <input
                className="input flex-1" placeholder="Where to?"
                value={dest} onChange={(e) => setDest(e.target.value)}
              />
              <button className="btn-primary whitespace-nowrap">See fares</button>
            </form>
          </div>

          <div className="relative">
            <div className="card p-6 max-w-sm ml-auto">
              <div className="flex justify-between items-center mb-4">
                <span className="font-display font-semibold">Sedan · arriving in 4 min</span>
                <span className="w-2.5 h-2.5 rounded-full bg-transit animate-pulse" />
              </div>
              <div className="h-40 rounded-xl bg-gradient-to-br from-mist to-paper border border-slate-800/10 flex items-center justify-center text-4xl">
                🗺️
              </div>
              <div className="flex justify-between items-baseline mt-4">
                <span className="text-sm text-slate-600">Estimated fare</span>
                <span className="meter-number text-2xl font-bold text-signal">₹189.42</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <h2 className="font-display text-3xl font-bold mb-2">Pick your ride</h2>
        <p className="text-slate-600 mb-10">Seven vehicle types, one transparent fare engine.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map((s) => (
            <div key={s.title} className="card p-6 hover:-translate-y-1 transition-transform">
              <span className="text-4xl">{s.emoji}</span>
              <h3 className="font-display font-semibold text-lg mt-3">{s.title}</h3>
              <p className="text-slate-600 text-sm mt-1">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="bg-mist py-20">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="font-display text-3xl font-bold mb-10">Why riders and drivers stay</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {WHY.map((w, i) => (
              <div key={w.title}>
                <span className="font-mono text-signal text-sm">0{i + 1}</span>
                <h3 className="font-display font-semibold text-xl mt-2 mb-2">{w.title}</h3>
                <p className="text-slate-600 text-sm">{w.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DRIVER REGISTRATION CTA */}
      <section className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h2 className="font-display text-3xl font-bold mb-4">Drive when you want. Earn what you track.</h2>
          <p className="text-slate-600 mb-6">
            Set your own hours, see today's earnings update in real time, and get paid out weekly. Sign up in minutes — document review usually takes under a day.
          </p>
          <button onClick={() => navigate('/signup')} className="btn-secondary">Start driving</button>
        </div>
        <div className="card p-6">
          <p className="text-sm text-slate-600 mb-2">This week's earnings</p>
          <div className="flex items-end gap-2 h-32">
            {[40, 65, 50, 80, 95, 60, 70].map((h, i) => (
              <div key={i} className="flex-1 bg-signal/80 rounded-t-md" style={{ height: `${h}%` }} />
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-ink text-paper py-20">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="font-display text-3xl font-bold mb-10">What people are saying</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="bg-white/5 border border-white/10 rounded-xl2 p-6">
                <p className="text-paper/80 text-sm mb-4">"{t.quote}"</p>
                <p className="font-display font-semibold">{t.name}</p>
                <p className="text-paper/50 text-xs">{t.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-4xl mx-auto px-6 py-20">
        <h2 className="font-display text-3xl font-bold mb-10">Frequently asked</h2>
        <div className="space-y-3">
          {FAQS.map((f) => (
            <details key={f.q} className="card p-5 group">
              <summary className="font-display font-semibold cursor-pointer list-none flex justify-between items-center">
                {f.q}
                <span className="text-signal group-open:rotate-45 transition-transform">+</span>
              </summary>
              <p className="text-slate-600 text-sm mt-3">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* CONTACT */}
      <section className="bg-mist py-20">
        <div className="max-w-2xl mx-auto px-6">
          <h2 className="font-display text-3xl font-bold mb-2">Still have questions?</h2>
          <p className="text-slate-600 mb-8">Send us a message — we read every one.</p>
          <form onSubmit={handleContact} className="card p-6 space-y-4">
            <input required placeholder="Your name" className="input" value={contactForm.name} onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })} />
            <input required type="email" placeholder="Email" className="input" value={contactForm.email} onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })} />
            <textarea required placeholder="Message" rows={4} className="input" value={contactForm.message} onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })} />
            <button className="btn-primary w-full">Send message</button>
          </form>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-ink text-paper/60 py-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between gap-6">
          <div>
            <span className="font-display font-bold text-paper text-lg">RideHail</span>
            <p className="text-sm mt-1">Go anywhere, right now.</p>
          </div>
          <div className="flex gap-6 text-sm">
            <a href="#" className="hover:text-paper">Twitter</a>
            <a href="#" className="hover:text-paper">Instagram</a>
            <a href="#" className="hover:text-paper">LinkedIn</a>
          </div>
        </div>
        <p className="text-center text-xs mt-8">© {new Date().getFullYear()} RideHail. Demo project — not a real service.</p>
      </footer>
    </div>
  );
}
