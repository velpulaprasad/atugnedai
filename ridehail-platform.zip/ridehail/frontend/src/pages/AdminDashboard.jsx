import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useToast } from '../components/Toast';
import LoadingSkeleton from '../components/LoadingSkeleton';

const TABS = ['Overview', 'Users', 'Driver Approval', 'Ride Monitoring', 'Feedback', 'Promo Codes'];

export default function AdminDashboard() {
  const [tab, setTab] = useState('Overview');
  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <h1 className="font-display text-2xl font-bold mb-6">Admin console</h1>
      <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition ${
              tab === t ? 'bg-ink text-paper' : 'bg-mist text-slate-600 hover:bg-slate-800/10'
            }`}>
            {t}
          </button>
        ))}
      </div>
      {tab === 'Overview' && <Overview />}
      {tab === 'Users' && <Users />}
      {tab === 'Driver Approval' && <DriverApproval />}
      {tab === 'Ride Monitoring' && <RideMonitoring />}
      {tab === 'Feedback' && <Feedback />}
      {tab === 'Promo Codes' && <PromoCodes />}
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="card p-5">
      <p className="text-slate-600 text-xs uppercase tracking-wide font-semibold">{label}</p>
      <p className="meter-number text-2xl font-bold mt-1">{value}</p>
    </div>
  );
}

function Overview() {
  const [data, setData] = useState(null);
  useEffect(() => { api.get('/admin/overview').then((r) => setData(r.data)); }, []);
  if (!data) return <LoadingSkeleton rows={4} />;
  const max = Math.max(1, ...data.revenueChart.map((d) => d.total));
  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard label="Total Users" value={data.totalUsers} />
        <StatCard label="Total Drivers" value={data.totalDrivers} />
        <StatCard label="Active Drivers" value={data.activeDrivers} />
        <StatCard label="Total Trips" value={data.totalTrips} />
        <StatCard label="Revenue" value={`₹${data.totalRevenue.toFixed(0)}`} />
      </div>
      <div className="card p-6">
        <p className="font-display font-semibold mb-4">Revenue — last 14 days</p>
        <div className="flex items-end gap-2 h-40">
          {data.revenueChart.map((d, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full bg-transit/80 rounded-t-md" style={{ height: `${(d.total / max) * 100}%` }} />
              <span className="text-[9px] text-slate-600 rotate-0">{d.day}</span>
            </div>
          ))}
          {data.revenueChart.length === 0 && <p className="text-slate-600 text-sm">No revenue yet.</p>}
        </div>
      </div>
    </div>
  );
}

function Users() {
  const [users, setUsers] = useState(null);
  const { push } = useToast();
  function load() { api.get('/admin/users').then((r) => setUsers(r.data.users)); }
  useEffect(load, []);

  async function suspend(id) {
    await api.put(`/admin/users/${id}/suspend`);
    push('User suspended.', 'info');
    load();
  }

  return (
    <div className="card p-6 overflow-x-auto">
      {users === null && <LoadingSkeleton />}
      {users && (
        <table className="w-full text-sm">
          <thead><tr className="text-left text-slate-600 border-b border-slate-800/10">
            <th className="py-2 pr-4">Name</th><th className="py-2 pr-4">Email</th><th className="py-2 pr-4">Role</th>
            <th className="py-2 pr-4">Verified</th><th className="py-2 pr-4">Wallet</th><th></th>
          </tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b border-slate-800/5">
                <td className="py-2 pr-4 font-medium">{u.name}</td>
                <td className="py-2 pr-4">{u.email}</td>
                <td className="py-2 pr-4 capitalize">{u.role}</td>
                <td className="py-2 pr-4">{u.is_verified ? '✅' : '⛔'}</td>
                <td className="py-2 pr-4 meter-number">₹{Number(u.wallet_balance).toFixed(2)}</td>
                <td className="py-2"><button onClick={() => suspend(u.id)} className="text-coral text-xs font-semibold">Suspend</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function DriverApproval() {
  const [drivers, setDrivers] = useState(null);
  const { push } = useToast();
  function load() { api.get('/admin/drivers').then((r) => setDrivers(r.data.drivers)); }
  useEffect(load, []);

  async function setApproval(id, approval_status) {
    await api.put(`/admin/drivers/${id}/approval`, { approval_status });
    push(`Driver ${approval_status}.`, 'success');
    load();
  }

  return (
    <div className="space-y-3">
      {drivers === null && <LoadingSkeleton />}
      {drivers?.map((d) => (
        <div key={d.id} className="card p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <p className="font-medium">{d.name} <span className="text-xs text-slate-600">({d.email})</span></p>
            <p className="text-xs text-slate-600 capitalize">{d.vehicle_type} · {d.vehicle_number || 'No vehicle number'} · status: {d.approval_status}</p>
          </div>
          {d.approval_status === 'pending' && (
            <div className="flex gap-2">
              <button onClick={() => setApproval(d.id, 'approved')} className="btn-primary text-sm px-4 py-2">Approve</button>
              <button onClick={() => setApproval(d.id, 'rejected')} className="btn-ghost text-sm px-4 py-2 border-coral/40 text-coral">Reject</button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function RideMonitoring() {
  const [rides, setRides] = useState(null);
  const [status, setStatus] = useState('');
  useEffect(() => {
    api.get('/admin/rides', { params: status ? { status } : {} }).then((r) => setRides(r.data.rides));
  }, [status]);
  return (
    <div className="card p-6 overflow-x-auto">
      <select className="input sm:w-56 mb-4" value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="">All statuses</option>
        {['requested','accepted','ongoing','completed','cancelled'].map((s) => <option key={s} value={s}>{s}</option>)}
      </select>
      {rides === null && <LoadingSkeleton />}
      {rides && (
        <table className="w-full text-sm">
          <thead><tr className="text-left text-slate-600 border-b border-slate-800/10">
            <th className="py-2 pr-4">Passenger</th><th className="py-2 pr-4">Driver</th>
            <th className="py-2 pr-4">Route</th><th className="py-2 pr-4">Status</th><th className="py-2 pr-4">Fare</th>
          </tr></thead>
          <tbody>
            {rides.map((r) => (
              <tr key={r.id} className="border-b border-slate-800/5">
                <td className="py-2 pr-4">{r.passenger_name}</td>
                <td className="py-2 pr-4">{r.driver_name || '—'}</td>
                <td className="py-2 pr-4 max-w-xs truncate">{r.pickup_address} → {r.destination_address}</td>
                <td className="py-2 pr-4 capitalize">{r.ride_status}</td>
                <td className="py-2 pr-4 meter-number">₹{Number(r.fare_total || 0).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function Feedback() {
  const [feedback, setFeedback] = useState(null);
  useEffect(() => { api.get('/admin/feedback').then((r) => setFeedback(r.data.feedback)); }, []);
  return (
    <div className="space-y-3">
      {feedback === null && <LoadingSkeleton />}
      {feedback?.map((f) => (
        <div key={f.id} className="card p-5">
          <p className="text-sm font-medium">{f.passenger_name} → {f.driver_name || 'N/A'}</p>
          <p className="text-xs text-slate-600 mb-2">Rating: {'⭐'.repeat(f.rating_of_driver || 0)}</p>
          {f.review && <p className="text-sm text-slate-600">"{f.review}"</p>}
        </div>
      ))}
      {feedback?.length === 0 && <p className="text-slate-600 text-sm">No feedback yet.</p>}
    </div>
  );
}

function PromoCodes() {
  const [codes, setCodes] = useState(null);
  const [form, setForm] = useState({ code: '', discountPercent: '', maxUses: '' });
  const { push } = useToast();
  function load() { api.get('/admin/promo-codes').then((r) => setCodes(r.data.promoCodes)); }
  useEffect(load, []);

  async function create(e) {
    e.preventDefault();
    try {
      await api.post('/admin/promo-codes', {
        code: form.code.toUpperCase(), discountPercent: form.discountPercent ? Number(form.discountPercent) : undefined,
        maxUses: form.maxUses ? Number(form.maxUses) : undefined,
      });
      setForm({ code: '', discountPercent: '', maxUses: '' });
      load();
      push('Promo code created.', 'success');
    } catch (err) {
      push(err.response?.data?.error || 'Could not create promo code.', 'error');
    }
  }

  async function toggle(id) {
    await api.put(`/admin/promo-codes/${id}/toggle`);
    load();
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <form onSubmit={create} className="card p-6 space-y-3">
        <h3 className="font-display font-semibold mb-2">New promo code</h3>
        <input required className="input" placeholder="CODE" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
        <input className="input" placeholder="Discount %" value={form.discountPercent} onChange={(e) => setForm({ ...form, discountPercent: e.target.value })} />
        <input className="input" placeholder="Max uses" value={form.maxUses} onChange={(e) => setForm({ ...form, maxUses: e.target.value })} />
        <button className="btn-primary w-full">Create</button>
      </form>
      <div className="card p-6">
        <h3 className="font-display font-semibold mb-3">Existing codes</h3>
        {codes === null && <LoadingSkeleton rows={2} />}
        <div className="space-y-2">
          {codes?.map((c) => (
            <div key={c.id} className="flex justify-between items-center border-b border-slate-800/5 pb-2">
              <div>
                <p className="font-mono font-semibold text-sm">{c.code}</p>
                <p className="text-xs text-slate-600">{c.discount_percent ? `${c.discount_percent}% off` : `₹${c.discount_flat} off`} · used {c.used_count}/{c.max_uses ?? '∞'}</p>
              </div>
              <button onClick={() => toggle(c.id)} className={`text-xs font-semibold ${c.active ? 'text-coral' : 'text-transit'}`}>
                {c.active ? 'Deactivate' : 'Activate'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
