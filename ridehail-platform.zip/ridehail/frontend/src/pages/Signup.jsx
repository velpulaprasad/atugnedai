import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

export default function Signup() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', role: 'passenger' });
  const [loading, setLoading] = useState(false);
  const { loginWithToken } = useAuth();
  const { push } = useToast();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post('/auth/signup', form);
      loginWithToken(data.token, data.user);
      push('Account created! Verification email sent (demo — auto-verified).', 'success');
      navigate(data.user.role === 'driver' ? '/driver' : '/dashboard');
    } catch (err) {
      push(err.response?.data?.error || 'Signup failed.', 'error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-ink flex items-center justify-center px-6 py-12">
      <div className="card w-full max-w-md p-8">
        <h1 className="font-display text-2xl font-bold mb-1">Create your account</h1>
        <p className="text-slate-600 text-sm mb-6">Ride, or drive and earn — your choice.</p>

        <div className="grid grid-cols-2 gap-3 mb-5">
          {['passenger', 'driver'].map((role) => (
            <button
              key={role}
              type="button"
              onClick={() => setForm({ ...form, role })}
              className={`py-2.5 rounded-xl2 border-2 font-medium text-sm capitalize transition ${
                form.role === role ? 'border-signal bg-signal/10' : 'border-slate-800/10'
              }`}
            >
              {role === 'passenger' ? '🧍 Ride' : '🚗 Drive'}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Full name</label>
            <input required className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <label className="label">Email</label>
            <input type="email" required className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <label className="label">Phone</label>
            <input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div>
            <label className="label">Password</label>
            <input type="password" required minLength={6} className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? 'Creating account…' : 'Create account'}
          </button>
        </form>

        <p className="text-sm text-slate-600 mt-6 text-center">
          Already have an account? <Link to="/login" className="text-transit font-semibold">Log in</Link>
        </p>
      </div>
    </div>
  );
}
