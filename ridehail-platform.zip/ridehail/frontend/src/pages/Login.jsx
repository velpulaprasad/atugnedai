import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { loginWithToken } = useAuth();
  const { push } = useToast();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post('/auth/login', form);
      loginWithToken(data.token, data.user);
      push(`Welcome back, ${data.user.name.split(' ')[0]}!`, 'success');
      navigate(data.user.role === 'admin' ? '/admin' : data.user.role === 'driver' ? '/driver' : '/dashboard');
    } catch (err) {
      push(err.response?.data?.error || 'Login failed.', 'error');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-ink flex items-center justify-center px-6">
      <div className="card w-full max-w-md p-8">
        <h1 className="font-display text-2xl font-bold mb-1">Welcome back</h1>
        <p className="text-slate-600 text-sm mb-6">Log in to book or drive.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Email</label>
            <input
              type="email" required className="input" value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="label">Password</label>
            <input
              type="password" required className="input" value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder="••••••••"
            />
          </div>
          <div className="text-right">
            <Link to="/forgot-password" className="text-xs text-transit font-medium">Forgot password?</Link>
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? 'Logging in…' : 'Log in'}
          </button>
        </form>

        <p className="text-sm text-slate-600 mt-6 text-center">
          New here? <Link to="/signup" className="text-transit font-semibold">Create an account</Link>
        </p>

        <div className="mt-6 pt-6 border-t border-slate-800/10 text-xs text-slate-600 space-y-1">
          <p className="font-semibold">Demo accounts (password: password123)</p>
          <p>Passenger — riya@example.com</p>
          <p>Driver — sanjay.driver@example.com</p>
          <p>Admin — admin@ridehail.dev</p>
        </div>
      </div>
    </div>
  );
}
