import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../components/Toast';
import LoadingSkeleton from '../components/LoadingSkeleton';

const TABS = ['Overview', 'Ride History', 'Saved Places', 'Wallet', 'Notifications', 'Profile'];

export default function PassengerDashboard() {
  const [tab, setTab] = useState('Overview');
  const { user, setUser } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-2xl font-bold">Hi, {user.name.split(' ')[0]} 👋</h1>
          <p className="text-slate-600 text-sm">Where are we headed today?</p>
        </div>
        <button onClick={() => navigate('/book')} className="btn-primary">Book a ride</button>
      </div>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition ${
              tab === t ? 'bg-ink text-paper' : 'bg-mist text-slate-600 hover:bg-slate-800/10'
            }`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'Overview' && <Overview user={user} navigate={navigate} />}
      {tab === 'Ride History' && <RideHistory />}
      {tab === 'Saved Places' && <SavedPlaces />}
      {tab === 'Wallet' && <Wallet user={user} />}
      {tab === 'Notifications' && <Notifications />}
      {tab === 'Profile' && <ProfileTab user={user} setUser={setUser} />}
    </div>
  );
}

function Overview({ user, navigate }) {
  const [activeRide, setActiveRide] = useState(undefined);

  useEffect(() => {
    api.get('/rides/active').then(({ data }) => setActiveRide(data.ride));
  }, []);

  return (
    <div className="grid md:grid-cols-3 gap-5">
      <div className="card p-6 md:col-span-2">
        <h3 className="font-display font-semibold mb-3">Current ride</h3>
        {activeRide === undefined && <LoadingSkeleton rows={1} />}
        {activeRide === null && (
          <div className="text-center py-8">
            <p className="text-slate-600 mb-4">No active ride right now.</p>
            <button onClick={() => navigate('/book')} className="btn-primary">Book one now</button>
          </div>
        )}
        {activeRide && (
          <div>
            <p className="font-medium">{activeRide.pickup_address} → {activeRide.destination_address}</p>
            <p className="text-sm text-slate-600 capitalize mt-1">Status: {activeRide.ride_status}</p>
            <button onClick={() => navigate('/book')} className="btn-secondary mt-4 text-sm px-4 py-2">Open tracking</button>
          </div>
        )}
      </div>
      <div className="card p-6">
        <h3 className="font-display font-semibold mb-2">Wallet balance</h3>
        <p className="meter-number text-3xl font-bold text-signal">₹{Number(user.wallet_balance || 0).toFixed(2)}</p>
      </div>
    </div>
  );
}

function RideHistory() {
  const [rides, setRides] = useState(null);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');

  useEffect(() => {
    const params = {};
    if (search) params.search = search;
    if (status) params.status = status;
    api.get('/rides/mine', { params }).then(({ data }) => setRides(data.rides));
  }, [search, status]);

  return (
    <div className="card p-6">
      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <input className="input" placeholder="Search by address…" value={search} onChange={(e) => setSearch(e.target.value)} />
        <select className="input sm:w-48" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">All statuses</option>
          {['requested','accepted','ongoing','completed','cancelled'].map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      {rides === null && <LoadingSkeleton />}
      {rides?.length === 0 && <p className="text-slate-600 text-sm text-center py-8">No rides found.</p>}
      <div className="space-y-3">
        {rides?.map((r) => (
          <div key={r.id} className="flex items-center justify-between border-b border-slate-800/5 pb-3">
            <div>
              <p className="font-medium text-sm">{r.pickup_address} → {r.destination_address}</p>
              <p className="text-xs text-slate-600 capitalize">{r.ride_status} · {new Date(r.created_at).toLocaleDateString()}</p>
            </div>
            <p className="meter-number font-semibold">₹{Number(r.fare_total || 0).toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function SavedPlaces() {
  const [addresses, setAddresses] = useState(null);
  const [form, setForm] = useState({ label: '', address: '', lat: '', lng: '' });
  const { push } = useToast();

  function load() {
    api.get('/users/addresses').then(({ data }) => setAddresses(data.addresses));
  }
  useEffect(load, []);

  async function addAddress(e) {
    e.preventDefault();
    try {
      await api.post('/users/addresses', { ...form, lat: parseFloat(form.lat), lng: parseFloat(form.lng) });
      setForm({ label: '', address: '', lat: '', lng: '' });
      load();
      push('Address saved.', 'success');
    } catch {
      push('Could not save address.', 'error');
    }
  }

  async function remove(id) {
    await api.delete(`/users/addresses/${id}`);
    load();
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="card p-6">
        <h3 className="font-display font-semibold mb-4">Add a favorite location</h3>
        <form onSubmit={addAddress} className="space-y-3">
          <input required className="input" placeholder="Label (e.g. Home)" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} />
          <input required className="input" placeholder="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <input required className="input" placeholder="Latitude" value={form.lat} onChange={(e) => setForm({ ...form, lat: e.target.value })} />
            <input required className="input" placeholder="Longitude" value={form.lng} onChange={(e) => setForm({ ...form, lng: e.target.value })} />
          </div>
          <button className="btn-primary w-full">Save address</button>
        </form>
      </div>
      <div className="card p-6">
        <h3 className="font-display font-semibold mb-4">Saved</h3>
        {addresses === null && <LoadingSkeleton rows={2} />}
        <div className="space-y-3">
          {addresses?.map((a) => (
            <div key={a.id} className="flex justify-between items-start border-b border-slate-800/5 pb-3">
              <div>
                <p className="font-medium text-sm">{a.label}</p>
                <p className="text-xs text-slate-600">{a.address}</p>
              </div>
              <button onClick={() => remove(a.id)} className="text-coral text-xs font-semibold">Remove</button>
            </div>
          ))}
          {addresses?.length === 0 && <p className="text-slate-600 text-sm">No saved addresses yet.</p>}
        </div>
      </div>
    </div>
  );
}

function Wallet({ user }) {
  return (
    <div className="card p-8 max-w-md">
      <p className="text-slate-600 text-sm mb-1">Available balance</p>
      <p className="meter-number text-4xl font-bold text-signal mb-6">₹{Number(user.wallet_balance || 0).toFixed(2)}</p>
      <p className="text-xs text-slate-600">
        Top-ups are simulated in this demo. In production this screen would connect to a real payment gateway.
      </p>
    </div>
  );
}

function Notifications() {
  const [items, setItems] = useState(null);
  useEffect(() => {
    api.get('/users/notifications').then(({ data }) => setItems(data.notifications));
  }, []);
  return (
    <div className="card p-6">
      {items === null && <LoadingSkeleton />}
      {items?.length === 0 && <p className="text-slate-600 text-sm text-center py-8">You're all caught up.</p>}
      <div className="space-y-3">
        {items?.map((n) => (
          <div key={n.id} className="border-b border-slate-800/5 pb-3">
            <p className="font-medium text-sm">{n.title}</p>
            <p className="text-xs text-slate-600">{n.message}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProfileTab({ user, setUser }) {
  const [form, setForm] = useState({ name: user.name, phone: user.phone || '' });
  const { push } = useToast();

  async function save(e) {
    e.preventDefault();
    const { data } = await api.put('/users/profile', form);
    setUser(data.user);
    localStorage.setItem('ridehail_user', JSON.stringify(data.user));
    push('Profile updated.', 'success');
  }

  return (
    <div className="card p-6 max-w-md">
      <form onSubmit={save} className="space-y-4">
        <div>
          <label className="label">Name</label>
          <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div>
          <label className="label">Phone</label>
          <input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        </div>
        <div>
          <label className="label">Email</label>
          <input disabled className="input opacity-60" value={user.email} />
        </div>
        <button className="btn-primary w-full">Save changes</button>
      </form>
    </div>
  );
}
