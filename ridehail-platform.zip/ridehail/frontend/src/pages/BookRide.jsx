import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useSocket } from '../context/SocketContext';
import { useToast } from '../components/Toast';
import MapView from '../components/MapView';
import VehicleCard from '../components/VehicleCard';
import FareBreakdown from '../components/FareBreakdown';
import { geocodeAddress, haversineKm, estimateDurationMin } from '../utils/geo';

const STATUS_COPY = {
  requested: 'Looking for a nearby driver…',
  accepted: 'Driver is on the way to pickup',
  arriving: 'Driver is arriving',
  arrived: 'Your driver has arrived',
  ongoing: 'Trip in progress',
  completed: 'Trip complete',
};

export default function BookRide() {
  const [step, setStep] = useState('form'); // form -> vehicles -> tracking -> rating
  const [pickupQuery, setPickupQuery] = useState('');
  const [destQuery, setDestQuery] = useState('');
  const [pickupResults, setPickupResults] = useState([]);
  const [destResults, setDestResults] = useState([]);
  const [pickup, setPickup] = useState(null);
  const [destination, setDestination] = useState(null);
  const [estimates, setEstimates] = useState([]);
  const [vehicleCatalog, setVehicleCatalog] = useState([]);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [promoCode, setPromoCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [ride, setRide] = useState(null);
  const [driverLoc, setDriverLoc] = useState(null);
  const [rating, setRating] = useState(5);

  const { socket } = useSocket();
  const { push } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/rides/vehicles').then(({ data }) => setVehicleCatalog(data.vehicles));
    api.get('/rides/active').then(({ data }) => {
      if (data.ride) {
        setRide(data.ride);
        setStep(data.ride.ride_status === 'completed' ? 'rating' : 'tracking');
      }
    });
  }, []);

  useEffect(() => {
    if (!socket || !ride) return;
    socket.emit('ride:join', ride.id);
    const onUpdate = (updated) => {
      if (updated.id !== ride.id) return;
      setRide(updated);
      if (updated.ride_status === 'completed') setStep('rating');
      if (updated.ride_status === 'cancelled') {
        push('Ride was cancelled.', 'error');
        resetFlow();
      }
    };
    const onDriverLoc = (loc) => setDriverLoc(loc);
    socket.on('ride:updated', onUpdate);
    socket.on('driver:location', onDriverLoc);
    return () => {
      socket.emit('ride:leave', ride.id);
      socket.off('ride:updated', onUpdate);
      socket.off('driver:location', onDriverLoc);
    };
  }, [socket, ride?.id]);

  async function searchPickup(q) {
    setPickupQuery(q);
    if (q.length < 3) return setPickupResults([]);
    setPickupResults(await geocodeAddress(q));
  }
  async function searchDest(q) {
    setDestQuery(q);
    if (q.length < 3) return setDestResults([]);
    setDestResults(await geocodeAddress(q));
  }

  async function getEstimates() {
    if (!pickup || !destination) return push('Choose pickup and destination first.', 'error');
    setLoading(true);
    try {
      const distanceKm = haversineKm(pickup.lat, pickup.lng, destination.lat, destination.lng);
      const durationMin = estimateDurationMin(distanceKm);
      const { data } = await api.post('/rides/estimate', { distanceKm, durationMin, promoCode: promoCode || undefined });
      setEstimates(data.estimates.map((e) => ({ ...e, distanceKm, durationMin })));
      setStep('vehicles');
    } catch (err) {
      push(err.response?.data?.error || 'Could not fetch fare estimate.', 'error');
    } finally {
      setLoading(false);
    }
  }

  async function confirmRide() {
    if (!selectedVehicle) return push('Select a vehicle.', 'error');
    setLoading(true);
    try {
      const { data } = await api.post('/rides', {
        vehicleType: selectedVehicle.vehicleType,
        pickupAddress: pickup.label, pickupLat: pickup.lat, pickupLng: pickup.lng,
        destinationAddress: destination.label, destinationLat: destination.lat, destinationLng: destination.lng,
        distanceKm: selectedVehicle.distanceKm, durationMin: selectedVehicle.durationMin,
        paymentMethod, promoCode: promoCode || undefined,
      });
      setRide(data.ride);
      setStep('tracking');
      push('Ride requested! Searching for a driver…', 'success');
    } catch (err) {
      push(err.response?.data?.error || 'Could not request ride.', 'error');
    } finally {
      setLoading(false);
    }
  }

  async function cancelRide() {
    if (!ride) return;
    await api.put(`/rides/${ride.id}/status`, { status: 'cancelled' });
    push('Ride cancelled.', 'info');
    resetFlow();
  }

  async function submitRating() {
    await api.post(`/rides/${ride.id}/review`, { rating, direction: 'to_driver' });
    push('Thanks for rating your driver!', 'success');
    resetFlow();
  }

  function resetFlow() {
    setRide(null); setDriverLoc(null); setStep('form');
    setPickup(null); setDestination(null); setEstimates([]); setSelectedVehicle(null);
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-8">
      <h1 className="font-display text-2xl font-bold mb-6">Book a ride</h1>

      {step === 'form' && (
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="card p-6 space-y-4">
            <div className="relative">
              <label className="label">Pickup location</label>
              <input className="input" placeholder="Search pickup…" value={pickupQuery}
                onChange={(e) => searchPickup(e.target.value)} />
              {pickupResults.length > 0 && !pickup && (
                <ul className="absolute z-10 bg-white border border-slate-800/10 rounded-xl mt-1 w-full max-h-48 overflow-auto shadow-soft">
                  {pickupResults.map((r, i) => (
                    <li key={i} className="px-4 py-2 text-sm hover:bg-mist cursor-pointer"
                      onClick={() => { setPickup(r); setPickupQuery(r.label); setPickupResults([]); }}>
                      {r.label}
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="relative">
              <label className="label">Destination</label>
              <input className="input" placeholder="Search destination…" value={destQuery}
                onChange={(e) => searchDest(e.target.value)} />
              {destResults.length > 0 && !destination && (
                <ul className="absolute z-10 bg-white border border-slate-800/10 rounded-xl mt-1 w-full max-h-48 overflow-auto shadow-soft">
                  {destResults.map((r, i) => (
                    <li key={i} className="px-4 py-2 text-sm hover:bg-mist cursor-pointer"
                      onClick={() => { setDestination(r); setDestQuery(r.label); setDestResults([]); }}>
                      {r.label}
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div>
              <label className="label">Promo code (optional)</label>
              <input className="input" placeholder="WELCOME20" value={promoCode} onChange={(e) => setPromoCode(e.target.value.toUpperCase())} />
            </div>
            <button onClick={getEstimates} disabled={loading} className="btn-primary w-full">
              {loading ? 'Calculating…' : 'See fare estimates'}
            </button>
          </div>
          <MapView pickup={pickup} destination={destination} height="420px" />
        </div>
      )}

      {step === 'vehicles' && (
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="space-y-3">
            <button onClick={() => setStep('form')} className="text-sm text-transit font-medium mb-2">← Change locations</button>
            {estimates.map((est) => {
              const meta = vehicleCatalog.find((v) => v.type === est.vehicleType);
              return (
                <VehicleCard key={est.vehicleType} estimate={est} capacity={meta?.capacity || 4}
                  selected={selectedVehicle?.vehicleType === est.vehicleType}
                  onSelect={() => setSelectedVehicle(est)} />
              );
            })}
            <div className="pt-2">
              <label className="label">Payment method</label>
              <div className="grid grid-cols-4 gap-2">
                {['cash', 'card', 'upi', 'wallet'].map((m) => (
                  <button key={m} onClick={() => setPaymentMethod(m)}
                    className={`py-2 rounded-xl text-xs font-semibold uppercase border-2 ${paymentMethod === m ? 'border-signal bg-signal/10' : 'border-slate-800/10'}`}>
                    {m}
                  </button>
                ))}
              </div>
            </div>
            <button onClick={confirmRide} disabled={loading || !selectedVehicle} className="btn-primary w-full mt-4">
              {loading ? 'Requesting…' : 'Confirm ride'}
            </button>
          </div>
          <div className="space-y-4">
            <MapView pickup={pickup} destination={destination} height="240px" />
            {selectedVehicle && (
              <FareBreakdown breakdown={selectedVehicle.breakdown} total={selectedVehicle.total}
                distanceKm={selectedVehicle.distanceKm} durationMin={selectedVehicle.durationMin} />
            )}
          </div>
        </div>
      )}

      {step === 'tracking' && ride && (
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="card p-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-2.5 h-2.5 rounded-full bg-signal animate-pulse" />
                <p className="font-display font-semibold">{STATUS_COPY[ride.ride_status] || ride.ride_status}</p>
              </div>
              <p className="text-sm text-slate-600">{ride.pickup_address} → {ride.destination_address}</p>
              <p className="meter-number text-2xl font-bold text-signal mt-3">₹{Number(ride.fare_total).toFixed(2)}</p>
            </div>
            {['requested', 'accepted'].includes(ride.ride_status) && (
              <button onClick={cancelRide} className="btn-ghost w-full border-coral/40 text-coral">Cancel ride</button>
            )}
          </div>
          <MapView pickup={pickup || { lat: ride.pickup_lat, lng: ride.pickup_lng }}
            destination={destination || { lat: ride.destination_lat, lng: ride.destination_lng }}
            driverLocation={driverLoc} height="360px" />
        </div>
      )}

      {step === 'rating' && ride && (
        <div className="card p-8 max-w-md mx-auto text-center">
          <h2 className="font-display text-xl font-bold mb-2">Trip complete!</h2>
          <p className="text-slate-600 mb-6">Total paid: <span className="meter-number font-semibold">₹{Number(ride.fare_total).toFixed(2)}</span></p>
          <p className="label mb-2">Rate your driver</p>
          <div className="flex justify-center gap-2 mb-6">
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} onClick={() => setRating(n)} className={`text-3xl ${n <= rating ? 'grayscale-0' : 'grayscale opacity-40'}`}>⭐</button>
            ))}
          </div>
          <button onClick={submitRating} className="btn-primary w-full">Submit rating</button>
        </div>
      )}
    </div>
  );
}
