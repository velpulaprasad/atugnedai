import { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';
import { useToast } from '../components/Toast';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [sent, setSent] = useState(false);
  const { push } = useToast();

  async function requestReset(e) {
    e.preventDefault();
    const { data } = await api.post('/auth/forgot-password', { email });
    setSent(true);
    // Demo mode: the backend returns the token directly since no email
    // provider is configured. In production this would be emailed instead.
    if (data.resetToken) setResetToken(data.resetToken);
    push(data.message, 'info');
  }

  async function submitReset(e) {
    e.preventDefault();
    try {
      await api.post('/auth/reset-password', { resetToken, newPassword });
      push('Password updated — you can log in now.', 'success');
    } catch (err) {
      push(err.response?.data?.error || 'Reset failed.', 'error');
    }
  }

  return (
    <div className="min-h-screen bg-ink flex items-center justify-center px-6">
      <div className="card w-full max-w-md p-8">
        <h1 className="font-display text-2xl font-bold mb-1">Reset your password</h1>
        <p className="text-slate-600 text-sm mb-6">
          {sent ? 'Enter the reset token and a new password.' : "We'll send a reset link to your email."}
        </p>

        {!sent ? (
          <form onSubmit={requestReset} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <input type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <button className="btn-primary w-full">Send reset link</button>
          </form>
        ) : (
          <form onSubmit={submitReset} className="space-y-4">
            <div>
              <label className="label">Reset token</label>
              <input required className="input font-mono text-xs" value={resetToken} onChange={(e) => setResetToken(e.target.value)} />
            </div>
            <div>
              <label className="label">New password</label>
              <input type="password" required minLength={6} className="input" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            </div>
            <button className="btn-primary w-full">Update password</button>
          </form>
        )}

        <p className="text-sm text-slate-600 mt-6 text-center">
          <Link to="/login" className="text-transit font-semibold">Back to login</Link>
        </p>
      </div>
    </div>
  );
}
