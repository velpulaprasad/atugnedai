import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { useToast } from '../components/Toast';
import MapView from '../components/MapView';
import LoadingSkeleton from '../components/LoadingSkeleton';

const TABS = ['Overview', 'Earnings', 'Vehicle & Documents', 'Profile'];

export default function DriverDashboard() {
  const [tab, setTab] = useState('Overview');
  const [driver, setDriver] = useState(null);
  const [activeRide, setActiveRide] = useState(undefined);
  const [incoming, setIncoming] = useState([]);
  const { socket } = useSocket();
  const { push } = useToast();

  function loadDriver() {
    api.get('/drivers/me').then(({ data }) => setDriver(data.driver));
  }
  function loadActiveRide() {
    api.get('/rides/active').then(({ data }) => setActiveRide(data.ride));
  }
  useEffect(() => { loadDriver(); loadActiveRide(); }, []);

  useEffect(() => {
    if (!socket) return;
    const onRequest = ({ ride, candidateDriverIds }) => {
      setIncoming((prev) => (prev.find((r) => r.id === ride.id) ? prev : [ride, ...prev].slice(0, 5)));
    };
    const onUpdate = (updated) => {
      setIncoming((prev) => prev.filter((r) => r.id !== updated.id));
      if (activeRide?.id === updated.id || updated.driver_id) loadActiveRide();
    };
    socket.on('ride:new-request', onRequest);
    socket.on('ride:updated', onUpdate);
    return () => {
      socket.off('ride:new-request', onRequest);
      socket.off('ride:updated', onUpdate);
    };
  }, [socket, activeRide?.id]);

  // Simulate a GPS heartbeat so the map + passenger tracking has something to show.
  useEffect(() => {
    if (!driver || driver.status !== 'online') return;
    const interval = setInterval(() => {
      const jitterLat = driver.current_lat + (Math.random() - 0.5) * 0.002;
      const jitterLng = driver.current_lng + (Math.random() - 0.5) * 0.002;
      api.put('/drivers/location', { lat: jitterLat, lng: jitterLng });
      if (socket && activeRide) socket.emit('driver:location', { rideId: activeRide.id, lat: jitterLat, lng: jitterLng });
    }, 4000);
    return () => clearInterval(interval);
  }, [driver, activeRide, socket]);

  async function toggleStatus() {
    const next = driver.status === 'online' ? 'offline' : 'online';
    const { data } = await api.put('/drivers/status', { status: next });
    setDriver(data.driver);
    push(`You're now ${next}.`, 'info');
  }

  async function acceptRide(rideId) {
    try {
      await api.put(`/rides/${rideId}/accept`);
      setIncoming((prev) => prev.filter((r) => r.id !== rideId));
      loadActiveRide();
      push('Ride accepted!', 'success');
    } catch (err) {
      push(err.response?.data?.error || 'Could not accept ride.', 'error');
      setIncoming((prev) => prev.filter((r) => r.id !== rideId));
    }
  }

  function rejectRide(rideId) {
    setIncoming((prev) => prev.filter((r) => r.id !== rideId));
  }

  async function advanceStatus(nextStatus) {
    const { data } = await api.put(`/rides/${activeRide.id}/status`, { status: nextStatus });
    setActiveRide(nextStatus === 'completed' ? null : data.ride);
    if (nextStatus === 'completed') { loadDriver(); push('Ride completed — fare recorded.', 'success'); }
  }

  if (!driver) return <div className="max-w-6xl mx-auto px-6 py-8"><LoadingSkeleton rows={4} /></div>;

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-2xl font-bold">Hi, {driver.name.split(' ')[0]} 🚗</h1>
          <p className="text-slate-600 text-sm">
            {driver.approval_status !== 'approved'
              ? `Account status: ${driver.approval_status} — you can go online once approved.`
              : `⭐ ${driver.rating_avg} · ${driver.total_trips} trips completed`}
          </p>
        </div>
        <button onClick={toggleStatus} disabled={driver.approval_status !== 'approved'}
          className={driver.status === 'online' ? 'btn-secondary' : 'btn-primary'}>
          {driver.status === 'online' ? 'Go offline' : 'Go online'}
        </button>
      </div>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition ${
              tab === t ? 'bg-ink text-paper' : 'bg-mist text-slate-600 hover:bg-slate-800/10'
            }`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'Overview' && (
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            {activeRide ? (
              <div className="card p-5">
                <p className="font-display font-semibold mb-1 capitalize">{activeRide.ride_status.replace('_', ' ')}</p>
                <p className="text-sm text-slate-600 mb-3">{activeRide.pickup_address} → {activeRide.destination_address}</p>
                <p className="meter-number text-xl font-bold text-signal mb-4">₹{Number(activeRide.fare_total).toFixed(2)}</p>
                <div className="flex flex-wrap gap-2">
                  {activeRide.ride_status === 'accepted' && <button onClick={() => advanceStatus('arriving')} className="btn-secondary text-sm px-4 py-2">Mark arriving</button>}
                  {activeRide.ride_status === 'arriving' && <button onClick={() => advanceStatus('arrived')} className="btn-secondary text-sm px-4 py-2">Mark arrived</button>}
                  {activeRide.ride_status === 'arrived' && <button onClick={() => advanceStatus('ongoing')} className="btn-secondary text-sm px-4 py-2">Start trip</button>}
                  {activeRide.ride_status === 'ongoing' && <button onClick={() => advanceStatus('completed')} className="btn-primary text-sm px-4 py-2">Complete trip</button>}
                </div>
              </div>
            ) : (
              <div className="card p-6">
                <h3 className="font-display font-semibold mb-3">Incoming requests</h3>
                {driver.status !== 'online' && <p className="text-slate-600 text-sm">Go online to start receiving ride requests.</p>}
                {driver.status === 'online' && incoming.length === 0 && <p className="text-slate-600 text-sm">Waiting for requests…</p>}
                <div className="space-y-3">
                  {incoming.map((r) => (
                    <div key={r.id} className="border border-slate-800/10 rounded-xl2 p-4">
                      <p className="text-sm font-medium">{r.pickup_address} → {r.destination_address}</p>
                      <p className="meter-number text-lg font-bold text-signal my-1">₹{Number(r.fare_total).toFixed(2)}</p>
                      <div className="flex gap-2 mt-2">
                        <button onClick={() => acceptRide(r.id)} className="btn-primary text-sm px-4 py-2 flex-1">Accept</button>
                        <button onClick={() => rejectRide(r.id)} className="btn-ghost text-sm px-4 py-2">Reject</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <MapView
            pickup={activeRide ? { lat: activeRide.pickup_lat, lng: activeRide.pickup_lng } : null}
            destination={activeRide ? { lat: activeRide.destination_lat, lng: activeRide.destination_lng } : null}
            driverLocation={driver.current_lat ? { lat: driver.current_lat, lng: driver.current_lng } : null}
            height="360px"
          />
        </div>
      )}

      {tab === 'Earnings' && <Earnings />}
      {tab === 'Vehicle & Documents' && <VehicleTab driver={driver} setDriver={setDriver} />}
      {tab === 'Profile' && <ProfileTab driver={driver} />}
    </div>
  );
}

function Earnings() {
  const [data, setData] = useState(null);
  useEffect(() => { api.get('/drivers/earnings').then((r) => setData(r.data)); }, []);
  if (!data) return <LoadingSkeleton rows={3} />;
  const max = Math.max(1, ...data.weekly.map((d) => d.total));
  return (
    <div className="grid md:grid-cols-3 gap-5">
      <div className="card p-6">
        <p className="text-slate-600 text-sm">Today</p>
        <p className="meter-number text-3xl font-bold text-signal">₹{data.today.total.toFixed(2)}</p>
        <p className="text-xs text-slate-600 mt-1">{data.today.trips} trips</p>
      </div>
      <div className="card p-6 md:col-span-2">
        <p className="text-slate-600 text-sm mb-3">This week</p>
        <div className="flex items-end gap-2 h-32">
          {data.weekly.map((d, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full bg-signal/80 rounded-t-md" style={{ height: `${(d.total / max) * 100}%` }} />
              <span className="text-[10px] text-slate-600">{d.day}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function VehicleTab({ driver, setDriver }) {
  const [form, setForm] = useState({
    vehicleType: driver.vehicle_type, vehicleNumber: driver.vehicle_number || '',
    drivingLicense: driver.driving_license || '',
  });
  const { push } = useToast();

  async function save(e) {
    e.preventDefault();
    const { data } = await api.put('/drivers/me', form);
    setDriver({ ...driver, ...data.driver });
    push('Vehicle details updated.', 'success');
  }

  function simulateUpload() {
    push('Document uploaded — pending admin review.', 'success');
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <form onSubmit={save} className="card p-6 space-y-4">
        <div>
          <label className="label">Vehicle type</label>
          <select className="input" value={form.vehicleType} onChange={(e) => setForm({ ...form, vehicleType: e.target.value })}>
            {['bike','auto','mini','sedan','suv','premium','ev'].map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Vehicle number</label>
          <input className="input" value={form.vehicleNumber} onChange={(e) => setForm({ ...form, vehicleNumber: e.target.value })} />
        </div>
        <div>
          <label className="label">Driving license number</label>
          <input className="input" value={form.drivingLicense} onChange={(e) => setForm({ ...form, drivingLicense: e.target.value })} />
        </div>
        <button className="btn-primary w-full">Save</button>
      </form>
      <div className="card p-6">
        <h3 className="font-display font-semibold mb-3">Documents</h3>
        <p className="text-sm text-slate-600 mb-4">Upload your license and registration for verification.</p>
        <button onClick={simulateUpload} className="btn-ghost w-full">Upload document (demo)</button>
        <p className="text-xs text-slate-600 mt-4">
          Approval status: <span className="font-semibold capitalize">{driver.approval_status}</span>
        </p>
      </div>
    </div>
  );
}

function ProfileTab({ driver }) {
  return (
    <div className="card p-6 max-w-md space-y-3">
      <div><p className="label">Name</p><p>{driver.name}</p></div>
      <div><p className="label">Email</p><p>{driver.email}</p></div>
      <div><p className="label">Phone</p><p>{driver.phone || '—'}</p></div>
      <div><p className="label">Wallet balance</p><p className="meter-number">₹{Number(driver.wallet_balance || 0).toFixed(2)}</p></div>
    </div>
  );
}
