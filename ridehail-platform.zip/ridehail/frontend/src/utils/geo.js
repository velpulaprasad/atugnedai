// Straight-line distance in km (haversine). Good enough for fare estimation
// in a demo; a production app would call a routing API for real road distance.
export function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function toRad(deg) {
  return (deg * Math.PI) / 180;
}

// Assumes an average city driving speed to turn distance into a duration estimate.
export function estimateDurationMin(distanceKm, avgSpeedKmh = 28) {
  return (distanceKm / avgSpeedKmh) * 60;
}

// Free, no-API-key geocoding via OpenStreetMap's Nominatim — fine for demo
// traffic levels; swap for a paid provider under real load.
export async function geocodeAddress(queryText) {
  const url = `https://nominatim.openstreetmap.org/search?format=json&limit=5&q=${encodeURIComponent(queryText)}`;
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error('Geocoding failed');
  const data = await res.json();
  return data.map((d) => ({
    label: d.display_name,
    lat: parseFloat(d.lat),
    lng: parseFloat(d.lon),
  }));
}
