const VEHICLE_META = {
  bike: { label: 'Bike', emoji: '🏍️', eta: '2 min' },
  auto: { label: 'Auto Rickshaw', emoji: '🛺', eta: '3 min' },
  mini: { label: 'Mini', emoji: '🚗', eta: '4 min' },
  sedan: { label: 'Sedan', emoji: '🚙', eta: '5 min' },
  suv: { label: 'SUV', emoji: '🚐', eta: '6 min' },
  premium: { label: 'Premium', emoji: '🚘', eta: '7 min' },
  ev: { label: 'Electric', emoji: '⚡', eta: '4 min' },
};

export default function VehicleCard({ estimate, capacity, selected, onSelect }) {
  const meta = VEHICLE_META[estimate.vehicleType] || { label: estimate.vehicleType, emoji: '🚗', eta: '5 min' };

  return (
    <button
      onClick={onSelect}
      className={`w-full flex items-center justify-between gap-4 p-4 rounded-xl2 border-2 transition-all text-left ${
        selected ? 'border-signal bg-signal/10 shadow-glow' : 'border-slate-800/10 hover:border-slate-800/25'
      }`}
    >
      <div className="flex items-center gap-3">
        <span className="text-3xl">{meta.emoji}</span>
        <div>
          <p className="font-display font-semibold text-slate-800">{meta.label}</p>
          <p className="text-xs text-slate-600">
            {capacity} seats · {meta.eta} away
          </p>
        </div>
      </div>
      <p className="meter-number text-lg font-semibold text-slate-800">₹{estimate.total.toFixed(2)}</p>
    </button>
  );
}
