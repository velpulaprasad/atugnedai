const LABELS = {
  baseFare: 'Base fare',
  distancePrice: 'Distance',
  timePrice: 'Time',
  peakCharge: 'Peak hour',
  nightCharge: 'Night charge',
  tax: 'Taxes',
  discount: 'Discount',
};

export default function FareBreakdown({ breakdown, total, distanceKm, durationMin }) {
  if (!breakdown) return null;
  return (
    <div className="card p-5">
      <div className="flex justify-between items-baseline mb-3">
        <h4 className="font-display font-semibold text-slate-800">Fare breakdown</h4>
        <span className="text-xs text-slate-600">{distanceKm} km · {Math.round(durationMin)} min</span>
      </div>
      <div className="space-y-1.5 text-sm">
        {Object.entries(breakdown).map(([key, value]) => {
          if (!value) return null;
          const isDiscount = key === 'discount';
          return (
            <div key={key} className="flex justify-between text-slate-600">
              <span>{LABELS[key] || key}</span>
              <span className="meter-number">
                {isDiscount ? '-' : ''}₹{Number(value).toFixed(2)}
              </span>
            </div>
          );
        })}
      </div>
      <div className="border-t border-slate-800/10 mt-3 pt-3 flex justify-between items-center">
        <span className="font-display font-semibold">Total</span>
        <span className="meter-number text-xl font-bold text-signal">₹{Number(total).toFixed(2)}</span>
      </div>
    </div>
  );
}
