import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Wraps a page and redirects to /login if not authenticated, or to the
// person's own dashboard if they're logged in but visiting the wrong role's area.
export default function ProtectedRoute({ children, allow }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-ink">
        <div className="w-10 h-10 border-4 border-signal border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;
  if (allow && !allow.includes(user.role)) {
    const home = user.role === 'admin' ? '/admin' : user.role === 'driver' ? '/driver' : '/dashboard';
    return <Navigate to={home} replace />;
  }
  return children;
}
