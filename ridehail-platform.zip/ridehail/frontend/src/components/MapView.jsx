import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';

// Leaflet's default marker icons reference image files that bundlers mangle;
// point them at the CDN copies so pins actually render.
const icon = (color) =>
  new L.DivIcon({
    className: '',
    html: `<div style="width:16px;height:16px;border-radius:50%;background:${color};border:3px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3)"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
  });

const pickupIcon = icon('#12867F');
const destIcon = icon('#FF5A5F');
const driverIcon = icon('#FFB020');

function FitBounds({ points }) {
  const map = useMap();
  useEffect(() => {
    if (points.length >= 2) {
      map.fitBounds(points, { padding: [40, 40] });
    } else if (points.length === 1) {
      map.setView(points[0], 14);
    }
  }, [JSON.stringify(points)]);
  return null;
}

// Generic map used across booking, ride tracking, and driver location display.
// pickup / destination / driverLocation are optional { lat, lng } objects.
export default function MapView({ pickup, destination, driverLocation, height = '360px', onMapClick }) {
  const points = [pickup, destination, driverLocation].filter(Boolean).map((p) => [p.lat, p.lng]);
  const center = points[0] || [23.0225, 72.5714]; // default center: Ahmedabad

  return (
    <div style={{ height }} className="rounded-xl2 overflow-hidden border border-slate-800/10">
      <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {pickup && (
          <Marker position={[pickup.lat, pickup.lng]} icon={pickupIcon}>
            <Popup>Pickup: {pickup.label || 'Selected point'}</Popup>
          </Marker>
        )}
        {destination && (
          <Marker position={[destination.lat, destination.lng]} icon={destIcon}>
            <Popup>Destination: {destination.label || 'Selected point'}</Popup>
          </Marker>
        )}
        {driverLocation && (
          <Marker position={[driverLocation.lat, driverLocation.lng]} icon={driverIcon}>
            <Popup>Driver</Popup>
          </Marker>
        )}
        {pickup && destination && (
          <Polyline positions={[[pickup.lat, pickup.lng], [destination.lat, destination.lng]]} color="#12867F" weight={4} opacity={0.6} dashArray="6 8" />
        )}
        <FitBounds points={points} />
        <ClickCapture onMapClick={onMapClick} />
      </MapContainer>
    </div>
  );
}

function ClickCapture({ onMapClick }) {
  const map = useMap();
  useEffect(() => {
    if (!onMapClick) return;
    const handler = (e) => onMapClick(e.latlng);
    map.on('click', handler);
    return () => map.off('click', handler);
  }, [map, onMapClick]);
  return null;
}
