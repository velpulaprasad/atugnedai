import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const home = user ? (user.role === 'admin' ? '/admin' : user.role === 'driver' ? '/driver' : '/dashboard') : '/';

  return (
    <nav className="sticky top-0 z-50 bg-ink/95 backdrop-blur border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to={home} className="flex items-center gap-2">
          <span className="w-8 h-8 rounded-lg bg-signal flex items-center justify-center font-display font-bold text-ink">R</span>
          <span className="font-display font-bold text-paper text-lg tracking-tight">RideHail</span>
        </Link>

        <div className="flex items-center gap-3">
          {!user && (
            <>
              <Link to="/login" className="text-paper/80 hover:text-paper text-sm font-medium">Log in</Link>
              <Link to="/signup" className="btn-primary text-sm px-4 py-2.5">Sign up</Link>
            </>
          )}
          {user && (
            <>
              <span className="text-paper/70 text-sm hidden sm:inline">Hi, {user.name.split(' ')[0]}</span>
              <button
                onClick={() => { logout(); navigate('/'); }}
                className="btn-ghost border-white/20 text-paper hover:bg-white/10 text-sm"
              >
                Log out
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
