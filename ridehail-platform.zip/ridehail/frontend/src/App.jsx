import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import { AuthProvider } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import { ToastProvider } from './components/Toast';

import Landing from './pages/Landing';
import Login from './pages/Login';
import Signup from './pages/Signup';
import ForgotPassword from './pages/ForgotPassword';
import PassengerDashboard from './pages/PassengerDashboard';
import BookRide from './pages/BookRide';
import DriverDashboard from './pages/DriverDashboard';
import AdminDashboard from './pages/AdminDashboard';

export default function App() {
  return (
    <AuthProvider>
      <SocketProvider>
        <ToastProvider>
          <Navbar />
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />

            <Route path="/dashboard" element={
              <ProtectedRoute allow={['passenger']}><PassengerDashboard /></ProtectedRoute>
            } />
            <Route path="/book" element={
              <ProtectedRoute allow={['passenger']}><BookRide /></ProtectedRoute>
            } />
            <Route path="/driver" element={
              <ProtectedRoute allow={['driver']}><DriverDashboard /></ProtectedRoute>
            } />
            <Route path="/admin" element={
              <ProtectedRoute allow={['admin']}><AdminDashboard /></ProtectedRoute>
            } />

            <Route path="*" element={<Landing />} />
          </Routes>
        </ToastProvider>
      </SocketProvider>
    </AuthProvider>
  );
}
