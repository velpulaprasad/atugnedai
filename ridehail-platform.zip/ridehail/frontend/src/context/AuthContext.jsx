import { createContext, useContext, useEffect, useState } from 'react';
import api from '../api/axios';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('ridehail_user');
    return stored ? JSON.parse(stored) : null;
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('ridehail_token');
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .get('/auth/me')
      .then(({ data }) => setUser(data.user))
      .catch(() => {
        localStorage.removeItem('ridehail_token');
        localStorage.removeItem('ridehail_user');
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, []);

  function loginWithToken(token, user) {
    localStorage.setItem('ridehail_token', token);
    localStorage.setItem('ridehail_user', JSON.stringify(user));
    setUser(user);
  }

  function logout() {
    localStorage.removeItem('ridehail_token');
    localStorage.removeItem('ridehail_user');
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, setUser, loading, loginWithToken, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
