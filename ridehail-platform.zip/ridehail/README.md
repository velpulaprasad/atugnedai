# RideHail — Uber-style ride booking platform (Phase 1: core working app)

A full-stack ride booking app: React + Tailwind frontend, Node/Express + Socket.IO
backend, PostgreSQL (Supabase) database. This is **Phase 1** — the complete
booking flow works end to end for real. Phase 2 (wallet top-ups, chat, SOS,
scheduled rides, PDF invoices, referrals, multi-language) is scaffolded in the
schema/sockets but not wired into the UI yet — see "What's stubbed" below.

## What actually works right now

- Sign up / log in / log out / forgot-password (JWT auth) for Passenger, Driver, Admin
- Landing page (hero, search, service cards, why-us, driver CTA, testimonials, FAQ, contact form)
- Passenger: book a ride (geocoded pickup/destination search, live fare estimate
  across all 7 vehicle types, vehicle selection, payment method), live map
  tracking of the assigned driver via Socket.IO, ride history with search/filter,
  saved addresses, wallet balance display, notifications, profile editing
- Driver: online/offline toggle, live incoming-ride-request feed, accept/reject,
  step through arriving → arrived → ongoing → completed, today's + weekly
  earnings chart, vehicle & document info, profile
- Admin: overview stats + revenue chart, user management (suspend), driver
  approval queue, ride monitoring table, feedback list, promo code CRUD
- Real fare engine: base + per-km + per-min + peak-hour + night charges + tax +
  promo discount, full breakdown shown before booking
- Real-time updates over Socket.IO: new ride requests pushed to nearby online
  drivers, ride status changes pushed to both rider and driver, live driver
  location on the tracking map
- Full Postgres schema + seed script with demo accounts

## What's stubbed for Phase 2

Wallet top-ups (balance is shown/read but there's no top-up UI), in-ride chat
and the SOS button (socket events exist server-side, no UI trigger yet),
scheduled rides, referral system, PDF invoices/receipts, multi-language,
dark mode toggle, and admin CSV export. The `promo_codes` table and API are
live; a nicer redemption UI is the main missing piece.

---

## Project structure

```
ridehail/
  backend/           Express API + Socket.IO
    src/
      config/db.js        Postgres connection pool
      middleware/auth.js  JWT verification + role guard
      routes/              auth, users, rides, drivers, admin
      sockets/index.js    Real-time event handlers
      utils/fare.js       Fare calculation engine
      seed.js             Demo data loader
    sql/schema.sql        Full database schema
  frontend/           React (Vite) + Tailwind
    src/
      api/axios.js         Configured HTTP client (attaches JWT)
      context/              Auth + Socket React contexts
      components/           Navbar, MapView (Leaflet), VehicleCard, FareBreakdown, Toast, etc.
      pages/                 Landing, Login, Signup, dashboards for each role, BookRide flow
```

---

## 1. Set up the database (Supabase)

1. Create a free project at [supabase.com](https://supabase.com).
2. Open the SQL editor and run the contents of `backend/sql/schema.sql`.
3. Go to **Project Settings → Database → Connection string → URI**. Copy it —
   you'll use it as `DATABASE_URL`. (Use the *Session pooler* connection
   string if you deploy the backend somewhere serverless.)

## 2. Run the backend

```bash
cd backend
cp .env.example .env      # then fill in DATABASE_URL and a random JWT_SECRET
npm install
npm run seed               # loads demo users, drivers, a sample ride, a promo code
npm run dev                 # starts on http://localhost:5000
```

Demo accounts created by the seed script (password for all: `password123`):

| Role      | Email                        |
|-----------|-------------------------------|
| Admin     | admin@ridehail.dev            |
| Passenger | riya@example.com              |
| Driver    | sanjay.driver@example.com (approved, online-ready) |
| Driver    | tarun.driver@example.com (pending approval — try approving it as admin) |

## 3. Run the frontend

```bash
cd frontend
cp .env.example .env       # defaults already point at localhost:5000
npm install
npm run dev                 # starts on http://localhost:5173
```

Open http://localhost:5173, log in with a demo account, and:
- As **riya@example.com**, book a ride — you'll see fare estimates for all 7
  vehicle types with a full breakdown.
- In another browser (or incognito), log in as **sanjay.driver@example.com**,
  go online, and accept the incoming request to watch both sides update live.
- As **admin@ridehail.dev**, approve the pending driver and watch the revenue
  chart and ride monitoring table.

---

## Deployment

**Database:** Supabase (already set up above) — nothing else to do.

**Backend → Render:**
1. Push this repo to GitHub.
2. New → Web Service on [render.com](https://render.com), point it at
   `backend/`, build command `npm install`, start command `npm start`.
3. Add environment variables from `.env.example` (use Supabase's connection
   string for `DATABASE_URL`, a long random string for `JWT_SECRET`, and set
   `CLIENT_ORIGIN` to your deployed frontend URL once you have it).

**Frontend → Netlify:**
1. New site from Git, point at `frontend/`, build command `npm run build`,
   publish directory `dist`.
2. Set `VITE_API_URL` and `VITE_SOCKET_URL` to your Render backend's URL
   (e.g. `https://ridehail-api.onrender.com/api` and
   `https://ridehail-api.onrender.com`).
3. Redeploy the backend once you know the final Netlify URL so `CLIENT_ORIGIN`
   matches (needed for CORS and Socket.IO).

---

## Notes on real-world gaps (by design, for a demo)

- **Geocoding** uses OpenStreetMap's free Nominatim API — fine for demo
  traffic, but rate-limited; swap for a paid geocoder under real load.
- **Routing/distance** uses a straight-line (haversine) estimate, not real
  road distance — swap in a routing API (OSRM, Mapbox Directions, etc.) for
  production-accurate fares and ETAs.
- **Payments** are fully simulated — no gateway is integrated, as requested.
- **Driver location** is simulated with random jitter around the driver's
  fixed seed location while "online," standing in for real GPS.
