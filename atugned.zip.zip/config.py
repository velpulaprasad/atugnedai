"""
config.py — Central configuration for Jarvis-Pro.

All tunables live here so the rest of the app never hardcodes
magic strings/numbers.
"""

import os
from pathlib import Path

# ----------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
ASSETS_DIR = BASE_DIR / "assets"
MEMORY_FILE = DATA_DIR / "memory.json"
LOGO_FILE = ASSETS_DIR / "logo.png"

# ----------------------------------------------------------------------
# Identity
# ----------------------------------------------------------------------
ASSISTANT_NAME = "Jarvis"
WAKE_WORD = "jarvis"          # word the wake-word listener waits for
USER_NAME_DEFAULT = "Sir"     # used until the user tells Jarvis their name

# ----------------------------------------------------------------------
# Speech (text-to-speech)
# ----------------------------------------------------------------------
VOICE_RATE = 180              # words per minute
VOICE_VOLUME = 1.0            # 0.0 - 1.0
VOICE_INDEX = 0                # index into pyttsx3's available voices list
ENABLE_VOICE_OUTPUT = True     # set False to force text-only replies

# ----------------------------------------------------------------------
# Speech (speech-to-text)
# ----------------------------------------------------------------------
ENABLE_VOICE_INPUT = True      # set False to disable the microphone entirely
LISTEN_TIMEOUT = 5             # seconds to wait for phrase to start
PHRASE_TIME_LIMIT = 10         # max seconds for a single utterance
AMBIENT_NOISE_DURATION = 0.7   # seconds spent calibrating for background noise

# ----------------------------------------------------------------------
# Brain / chatbot
# ----------------------------------------------------------------------
# If set (env var ANTHROPIC_API_KEY), the chatbot fallback will use the
# real Claude API for open-ended conversation. Otherwise it degrades
# gracefully to a small built-in pattern-based responder.
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = "claude-sonnet-4-6"
MAX_HISTORY_MESSAGES = 20      # how many past turns to keep for context

# ----------------------------------------------------------------------
# Safety switches
# ----------------------------------------------------------------------
# Destructive system actions (shutdown/restart/delete files) are OFF by
# default. Flip these only if you understand the risk.
ALLOW_SYSTEM_POWER_ACTIONS = False
ALLOW_FILE_DELETION = False

# ----------------------------------------------------------------------
# GUI theme
# ----------------------------------------------------------------------
THEME = {
    "bg": "#0b0f1a",
    "panel": "#121826",
    "accent": "#00e5ff",
    "accent_dim": "#0b7285",
    "text": "#e6f1ff",
    "text_dim": "#7d8aa3",
    "user_bubble": "#1c2536",
    "jarvis_bubble": "#003a4d",
    "danger": "#ff4d4f",
    "font_family": "Segoe UI",
}

WINDOW_TITLE = f"{ASSISTANT_NAME} — Advanced Desktop Assistant"
WINDOW_SIZE = "900x650"
