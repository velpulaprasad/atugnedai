# Jarvis-Pro

An advanced desktop AI assistant with a chat GUI, voice input/output, wake-word
listening, and system automation (apps, browser, files, system controls).

## Features

- **Dark-themed chat GUI** (Tkinter) with animated status indicator
  (idle / listening / thinking / speaking).
- **Voice input** via microphone (Google speech recognition through the
  `SpeechRecognition` library) and **voice output** via offline TTS (`pyttsx3`).
- **Wake-word listening** (`speech/wake_word.py`) — a lightweight polling
  approach; swap in Picovoice Porcupine for lower-latency production use.
- **Rule-based command engine** (`ai/commands.py`) for deterministic actions:
  time/date, battery/system info, screenshots, locking the screen, opening/
  closing apps, web & YouTube search, opening sites, file operations, and a
  "remember that / what's my ..." fact store.
- **Chatbot fallback** (`ai/chatbot.py`) for open-ended conversation. Uses the
  real Claude API if `ANTHROPIC_API_KEY` is set; otherwise falls back to a
  small offline responder so the app still works with zero configuration.
- **Persistent memory** (`data/memory.json`) — conversation history,
  preferences, and remembered facts survive restarts.

## Project layout

```
Jarvis-Pro/
├── app.py               # Entry point — run this
├── config.py            # All settings (name, wake word, theme, safety flags)
├── requirements.txt
├── gui/                  # Tkinter UI
├── ai/                   # brain, memory, command engine, chatbot
├── speech/               # listen (STT), speak (TTS), wake word
├── automation/           # apps, browser, system, files
├── data/memory.json      # persistent memory store
└── assets/logo.png
```

## Setup

```bash
cd Jarvis-Pro
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Notes on dependencies:
- `PyAudio` can be tricky to install on some platforms:
  - Windows: `pip install pipwin && pipwin install pyaudio` (if the plain
    pip install fails)
  - macOS: `brew install portaudio` before `pip install pyaudio`
  - Linux: `sudo apt-get install portaudio19-dev python3-pyaudio`
- If you don't need voice input at all, set `ENABLE_VOICE_INPUT = False` in
  `config.py` and skip `SpeechRecognition`/`PyAudio`.

### Optional: enable full conversational AI

By default, open-ended chat (anything that isn't a recognized command) uses a
small offline responder. To use the real Claude API instead:

```bash
export ANTHROPIC_API_KEY="your-key-here"   # Windows: set ANTHROPIC_API_KEY=...
```

## Run

```bash
python app.py
```

Type into the input box and press Enter / click **Send**, or click the 🎙
button to speak a single command (the mic button is disabled automatically if
no microphone is detected).

## Example commands

- "What time is it?" / "What's today's date?"
- "Open notepad" / "Close chrome"
- "Search the web for quantum computing"
- "Search youtube for lofi beats"
- "Go to github"
- "List files in ." / "Find files called report" / "Read the file notes.txt"
- "Remember that my wifi password is example123"
- "What's my wifi password?"
- "Battery" / "System info" / "Screenshot" / "Lock the screen"

## Safety switches

Two config flags default to **off** and must be explicitly enabled in
`config.py` before Jarvis will act on them:

- `ALLOW_SYSTEM_POWER_ACTIONS` — required for "shutdown"/"restart" to actually
  execute (otherwise Jarvis explains it's disabled).
- `ALLOW_FILE_DELETION` — required for "delete the file ..." to actually
  execute.

This prevents a misheard voice command from powering off your machine or
deleting a file.

## Extending Jarvis

- **New commands:** add a pattern + handler in `ai/commands.py`.
- **New automation:** add a function to the relevant module under
  `automation/` and wire it into a command rule.
- **Swap the wake-word engine:** replace the polling loop in
  `speech/wake_word.py` with a proper on-device keyword spotter (e.g.
  Porcupine) for much lower CPU usage and latency.
- **Theme:** all colors/fonts are in `config.THEME` — change once, applies
  everywhere.
