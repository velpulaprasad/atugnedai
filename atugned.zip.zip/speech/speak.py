"""
speech/speak.py — Text-to-speech output.

Wraps pyttsx3 (offline TTS, works on Windows/macOS/Linux). Falls back
to a no-op if the library or an audio backend isn't available so the
GUI never crashes just because voice output can't initialize.
"""

import threading

import config


class Speaker:
    def __init__(self):
        self._engine = None
        self._lock = threading.Lock()
        self._error = None
        if config.ENABLE_VOICE_OUTPUT:
            self._setup()

    def _setup(self):
        try:
            import pyttsx3
        except ImportError:
            self._error = "pyttsx3 is not installed (pip install pyttsx3)."
            return

        try:
            self._engine = pyttsx3.init()
            self._engine.setProperty("rate", config.VOICE_RATE)
            self._engine.setProperty("volume", config.VOICE_VOLUME)
            voices = self._engine.getProperty("voices")
            if voices and 0 <= config.VOICE_INDEX < len(voices):
                self._engine.setProperty("voice", voices[config.VOICE_INDEX].id)
        except Exception as exc:  # pragma: no cover - platform dependent
            self._error = f"Couldn't initialize text-to-speech ({exc})."
            self._engine = None

    @property
    def available(self) -> bool:
        return self._engine is not None

    @property
    def error(self):
        return self._error

    def speak(self, text: str, async_: bool = True):
        """Speak text. Runs in a background thread by default so the GUI stays responsive."""
        if not text or not self._engine:
            return

        def _run():
            with self._lock:
                try:
                    self._engine.say(text)
                    self._engine.runAndWait()
                except RuntimeError:
                    # Engine busy / re-entrant call; ignore rather than crash.
                    pass

        if async_:
            threading.Thread(target=_run, daemon=True).start()
        else:
            _run()
