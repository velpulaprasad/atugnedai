"""
speech/listen.py — Speech-to-text via the microphone.

Wraps the `speech_recognition` library. Every public function degrades
gracefully (returns None + a message) if no microphone or the library
is missing, so the rest of the app can always fall back to typed input.
"""

import config


class Listener:
    def __init__(self):
        self._sr = None
        self._recognizer = None
        self._mic_available = False
        self._init_error = None
        self._setup()

    def _setup(self):
        try:
            import speech_recognition as sr
        except ImportError as exc:
            self._init_error = (
                "speech_recognition is not installed (pip install SpeechRecognition pyaudio)."
            )
            return

        self._sr = sr
        self._recognizer = sr.Recognizer()
        try:
            with sr.Microphone() as source:
                self._recognizer.adjust_for_ambient_noise(
                    source, duration=config.AMBIENT_NOISE_DURATION
                )
            self._mic_available = True
        except (OSError, AttributeError) as exc:
            self._init_error = f"No usable microphone found ({exc})."

    @property
    def available(self) -> bool:
        return self._mic_available

    @property
    def error(self):
        return self._init_error

    def listen_once(self):
        """
        Blocks until a phrase is captured or timeout elapses.
        Returns (text, None) on success, or (None, message) on failure.
        """
        if not self._mic_available:
            return None, self._init_error or "Microphone is unavailable."

        sr = self._sr
        try:
            with sr.Microphone() as source:
                audio = self._recognizer.listen(
                    source,
                    timeout=config.LISTEN_TIMEOUT,
                    phrase_time_limit=config.PHRASE_TIME_LIMIT,
                )
        except sr.WaitTimeoutError:
            return None, "I didn't hear anything."

        try:
            text = self._recognizer.recognize_google(audio)
            return text, None
        except sr.UnknownValueError:
            return None, "I couldn't understand that."
        except sr.RequestError as exc:
            return None, f"Speech service error: {exc}"
