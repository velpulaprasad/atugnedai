"""
speech/wake_word.py — Simple wake-word listener.

This is a lightweight, dependency-minimal approximation of wake-word
detection: it repeatedly listens for short phrases and checks whether
the wake word appears in the transcript. For lower latency / lower CPU
usage in production, swap this for a dedicated engine such as Picovoice
Porcupine, which does on-device keyword spotting without full speech
recognition.
"""

import threading
import time

import config
from speech.listen import Listener


class WakeWordListener:
    def __init__(self, on_wake, listener: Listener = None):
        """
        on_wake: callable invoked (with no args) when the wake word is heard.
        """
        self.on_wake = on_wake
        self.listener = listener or Listener()
        self._running = False
        self._thread = None

    @property
    def available(self) -> bool:
        return self.listener.available

    def start(self):
        if self._running or not self.available:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        wake_word = config.WAKE_WORD.lower()
        while self._running:
            text, _err = self.listener.listen_once()
            if text and wake_word in text.lower():
                self.on_wake()
            time.sleep(0.05)  # tiny yield to avoid a hot loop on errors
