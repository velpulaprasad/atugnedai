"""
automation/files.py — Basic, guarded file operations.

Deletion is gated behind config.ALLOW_FILE_DELETION (default False)
to avoid an assistant accidentally destroying user data from a
misheard voice command.
"""

import os
from pathlib import Path

import config


def create_file(path: str, content: str = "") -> str:
    p = Path(path).expanduser()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Created file {p}."
    except OSError as exc:
        return f"Couldn't create {p} ({exc})."


def read_file(path: str, max_chars: int = 2000) -> str:
    p = Path(path).expanduser()
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
        if len(text) > max_chars:
            text = text[:max_chars] + "\n... (truncated)"
        return text
    except OSError as exc:
        return f"Couldn't read {p} ({exc})."


def list_dir(path: str = ".") -> str:
    p = Path(path).expanduser()
    try:
        entries = sorted(os.listdir(p))
        if not entries:
            return f"{p} is empty."
        return f"Contents of {p}:\n" + "\n".join(entries)
    except OSError as exc:
        return f"Couldn't list {p} ({exc})."


def search_files(keyword: str, root: str = ".", max_results: int = 25) -> str:
    root_path = Path(root).expanduser()
    keyword_lower = keyword.lower()
    matches = []
    try:
        for dirpath, _dirnames, filenames in os.walk(root_path):
            for fname in filenames:
                if keyword_lower in fname.lower():
                    matches.append(str(Path(dirpath) / fname))
                    if len(matches) >= max_results:
                        break
            if len(matches) >= max_results:
                break
    except OSError as exc:
        return f"Search failed ({exc})."

    if not matches:
        return f"No files matching '{keyword}' found under {root_path}."
    return f"Found {len(matches)} match(es):\n" + "\n".join(matches)


def delete_file(path: str) -> str:
    if not config.ALLOW_FILE_DELETION:
        return ("File deletion is disabled for safety. Set ALLOW_FILE_DELETION = True "
                "in config.py if you really want to enable this.")
    p = Path(path).expanduser()
    try:
        p.unlink()
        return f"Deleted {p}."
    except OSError as exc:
        return f"Couldn't delete {p} ({exc})."
