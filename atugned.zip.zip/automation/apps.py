"""
automation/apps.py — Open and close desktop applications.

Cross-platform best-effort implementation. Windows/macOS/Linux each
resolve application names differently, so we keep a small alias map
per platform and fall back to trying the raw name.
"""

import platform
import subprocess

SYSTEM = platform.system()  # "Windows", "Darwin", "Linux"

# Common aliases -> actual executable / bundle / command per platform.
_APP_ALIASES = {
    "Windows": {
        "notepad": "notepad.exe",
        "calculator": "calc.exe",
        "calc": "calc.exe",
        "paint": "mspaint.exe",
        "explorer": "explorer.exe",
        "file explorer": "explorer.exe",
        "chrome": "chrome.exe",
        "edge": "msedge.exe",
        "word": "winword.exe",
        "excel": "excel.exe",
        "vscode": "code.exe",
        "vs code": "code.exe",
        "terminal": "cmd.exe",
        "cmd": "cmd.exe",
        "powershell": "powershell.exe",
    },
    "Darwin": {
        "notes": "Notes",
        "calculator": "Calculator",
        "calc": "Calculator",
        "safari": "Safari",
        "chrome": "Google Chrome",
        "terminal": "Terminal",
        "vscode": "Visual Studio Code",
        "vs code": "Visual Studio Code",
        "mail": "Mail",
        "finder": "Finder",
    },
    "Linux": {
        "calculator": "gnome-calculator",
        "calc": "gnome-calculator",
        "files": "nautilus",
        "file explorer": "nautilus",
        "chrome": "google-chrome",
        "firefox": "firefox",
        "terminal": "gnome-terminal",
        "vscode": "code",
        "vs code": "code",
        "text editor": "gedit",
    },
}


def _resolve(name: str) -> str:
    name = name.strip().lower()
    aliases = _APP_ALIASES.get(SYSTEM, {})
    return aliases.get(name, name)


def open_app(name: str) -> str:
    """Attempt to open an application by common name. Returns a status message."""
    target = _resolve(name)
    try:
        if SYSTEM == "Windows":
            subprocess.Popen(["start", "", target], shell=True)
        elif SYSTEM == "Darwin":
            subprocess.Popen(["open", "-a", target])
        else:  # Linux and others
            subprocess.Popen([target])
        return f"Opening {name}."
    except (OSError, subprocess.SubprocessError) as exc:
        return f"I couldn't open {name} ({exc})."


def close_app(name: str) -> str:
    """Attempt to terminate all processes matching the given name."""
    try:
        import psutil
    except ImportError:
        return "The psutil package is required to close applications (pip install psutil)."

    target = name.strip().lower()
    killed = 0
    for proc in psutil.process_iter(["name"]):
        try:
            pname = (proc.info.get("name") or "").lower()
            if target in pname:
                proc.terminate()
                killed += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if killed:
        return f"Closed {killed} process(es) matching '{name}'."
    return f"I couldn't find a running process matching '{name}'."
