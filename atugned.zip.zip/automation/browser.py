"""
automation/browser.py — Web browsing helpers.

Uses the standard `webbrowser` module so it works cross-platform
without extra dependencies.
"""

import urllib.parse
import webbrowser

_SITE_SHORTCUTS = {
    "youtube": "https://www.youtube.com",
    "gmail": "https://mail.google.com",
    "github": "https://github.com",
    "google": "https://www.google.com",
    "maps": "https://maps.google.com",
    "amazon": "https://www.amazon.com",
    "wikipedia": "https://www.wikipedia.org",
    "netflix": "https://www.netflix.com",
    "twitter": "https://twitter.com",
    "x": "https://twitter.com",
    "linkedin": "https://www.linkedin.com",
    "reddit": "https://www.reddit.com",
}


def open_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    webbrowser.open(url)
    return f"Opening {url}."


def open_site(name: str) -> str:
    key = name.strip().lower()
    if key in _SITE_SHORTCUTS:
        webbrowser.open(_SITE_SHORTCUTS[key])
        return f"Opening {name.title()}."
    return open_url(name)


def search_web(query: str) -> str:
    q = urllib.parse.quote_plus(query.strip())
    webbrowser.open(f"https://www.google.com/search?q={q}")
    return f"Searching the web for '{query}'."


def search_youtube(query: str) -> str:
    q = urllib.parse.quote_plus(query.strip())
    webbrowser.open(f"https://www.youtube.com/results?search_query={q}")
    return f"Searching YouTube for '{query}'."
