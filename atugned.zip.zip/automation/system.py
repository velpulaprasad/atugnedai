"""
automation/system.py — System information and controls.

Power-off style actions (shutdown/restart/lock) are gated behind
config.ALLOW_SYSTEM_POWER_ACTIONS, which defaults to False, so the
assistant never turns a machine off unless the operator opts in.
"""

import os
import platform
import subprocess
from datetime import datetime

import config

SYSTEM = platform.system()


def get_time() -> str:
    return datetime.now().strftime("It's %I:%M %p.")


def get_date() -> str:
    return datetime.now().strftime("Today is %A, %B %d, %Y.")


def get_battery() -> str:
    try:
        import psutil
        battery = psutil.sensors_battery()
    except ImportError:
        return "The psutil package is required to read battery status."
    if battery is None:
        return "This device doesn't report battery information (likely a desktop)."
    plugged = "plugged in" if battery.power_plugged else "on battery"
    return f"Battery is at {battery.percent}% and {plugged}."


def get_system_info() -> str:
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory().percent
        return (f"CPU usage is {cpu}%, memory usage is {mem}%, "
                f"running {platform.system()} {platform.release()}.")
    except ImportError:
        return f"Running {platform.system()} {platform.release()}."


def take_screenshot(save_path=None) -> str:
    try:
        from PIL import ImageGrab
    except ImportError:
        return "The Pillow package is required for screenshots (pip install Pillow)."
    save_path = save_path or os.path.join(
        os.path.expanduser("~"), f"jarvis_screenshot_{datetime.now():%Y%m%d_%H%M%S}.png"
    )
    try:
        img = ImageGrab.grab()
        img.save(save_path)
        return f"Screenshot saved to {save_path}."
    except Exception as exc:  # pragma: no cover - platform dependent
        return f"Couldn't take a screenshot ({exc})."


def lock_screen() -> str:
    try:
        if SYSTEM == "Windows":
            subprocess.run(["rundll32.exe", "user32.dll,LockWorkStation"], check=False)
        elif SYSTEM == "Darwin":
            subprocess.run(
                ["/System/Library/CoreServices/Menu Extras/User.menu/Contents/Resources/CGSession", "-suspend"],
                check=False,
            )
        else:
            subprocess.run(["loginctl", "lock-session"], check=False)
        return "Locking the screen."
    except Exception as exc:  # pragma: no cover
        return f"Couldn't lock the screen ({exc})."


def shutdown() -> str:
    if not config.ALLOW_SYSTEM_POWER_ACTIONS:
        return ("Shutdown is disabled for safety. Set ALLOW_SYSTEM_POWER_ACTIONS = True "
                "in config.py if you really want to enable this.")
    try:
        if SYSTEM == "Windows":
            subprocess.run(["shutdown", "/s", "/t", "5"], check=False)
        else:
            subprocess.run(["shutdown", "-h", "now"], check=False)
        return "Shutting down."
    except Exception as exc:  # pragma: no cover
        return f"Couldn't shut down ({exc})."


def restart() -> str:
    if not config.ALLOW_SYSTEM_POWER_ACTIONS:
        return ("Restart is disabled for safety. Set ALLOW_SYSTEM_POWER_ACTIONS = True "
                "in config.py if you really want to enable this.")
    try:
        if SYSTEM == "Windows":
            subprocess.run(["shutdown", "/r", "/t", "5"], check=False)
        else:
            subprocess.run(["shutdown", "-r", "now"], check=False)
        return "Restarting."
    except Exception as exc:  # pragma: no cover
        return f"Couldn't restart ({exc})."
