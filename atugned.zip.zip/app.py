"""
app.py — Entry point for Jarvis-Pro.

Run with:  python app.py
"""

import sys

import config


def main():
    try:
        from gui.main_window import run
    except ImportError as exc:
        print(f"Failed to import GUI (is tkinter installed?): {exc}")
        sys.exit(1)

    print(f"Starting {config.ASSISTANT_NAME}...")
    if not config.ANTHROPIC_API_KEY:
        print("Note: ANTHROPIC_API_KEY is not set — running with offline chat fallback.")
    run()


if __name__ == "__main__":
    main()
