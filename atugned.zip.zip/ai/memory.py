"""
ai/memory.py — Persistent memory for Jarvis.

Stores conversation history, user preferences, and free-form
"remembered facts" (e.g. "remember that my wifi password is X")
in a simple JSON file so the assistant has continuity across runs.
"""

import json
import threading
from datetime import datetime

import config


class Memory:
    """Thread-safe JSON-backed memory store."""

    def __init__(self, path=None):
        self.path = path or config.MEMORY_FILE
        self._lock = threading.Lock()
        self._data = {
            "conversations": [],
            "preferences": {},
            "facts": {},
        }
        self._load()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------
    def _load(self):
        with self._lock:
            if self.path.exists():
                try:
                    with open(self.path, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                    for key in self._data:
                        if key in loaded:
                            self._data[key] = loaded[key]
                except (json.JSONDecodeError, OSError):
                    # Corrupt or unreadable file: start fresh rather than crash.
                    pass
            else:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                self._save_locked()

    def _save_locked(self):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2, ensure_ascii=False)

    def save(self):
        with self._lock:
            self._save_locked()

    # ------------------------------------------------------------------
    # Conversation history
    # ------------------------------------------------------------------
    def add_conversation(self, speaker, text):
        with self._lock:
            self._data["conversations"].append({
                "speaker": speaker,
                "text": text,
                "timestamp": datetime.now().isoformat(timespec="seconds"),
            })
            # Keep the file from growing forever.
            self._data["conversations"] = self._data["conversations"][-500:]
            self._save_locked()

    def get_history(self, limit=20):
        with self._lock:
            return list(self._data["conversations"][-limit:])

    def clear_history(self):
        with self._lock:
            self._data["conversations"] = []
            self._save_locked()

    # ------------------------------------------------------------------
    # Preferences (structured key/value settings)
    # ------------------------------------------------------------------
    def set_preference(self, key, value):
        with self._lock:
            self._data["preferences"][key] = value
            self._save_locked()

    def get_preference(self, key, default=None):
        with self._lock:
            return self._data["preferences"].get(key, default)

    # ------------------------------------------------------------------
    # Free-form facts ("remember that ...")
    # ------------------------------------------------------------------
    def remember_fact(self, key, value):
        with self._lock:
            self._data["facts"][key.strip().lower()] = value
            self._save_locked()

    def recall_fact(self, key):
        with self._lock:
            return self._data["facts"].get(key.strip().lower())

    def all_facts(self):
        with self._lock:
            return dict(self._data["facts"])
