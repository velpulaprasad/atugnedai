"""
ai/commands.py — Intent matching and dispatch to automation modules.

Design: a list of (patterns, handler) rules. Each rule's patterns are
regexes; the first matching rule wins. Handlers receive the regex match
object and the Memory instance so they can read/write state ("remember
that ..." / "what's my ...").

This is intentionally simple (rule-based) rather than a full NLU
pipeline — predictable, debuggable, and easy to extend with new rules.
"""

import re

from automation import apps, browser, files, system


def _rule(*patterns):
    return [re.compile(p, re.IGNORECASE) for p in patterns]


class CommandEngine:
    def __init__(self, memory):
        self.memory = memory
        # Order matters: more specific rules should come first.
        self.rules = [
            (_rule(r"^(?:what'?s|what is)?\s*(?:the )?time\b", r"^what time is it"), self._time),
            (_rule(r"^(?:what'?s|what is)?\s*(?:the |today'?s )?date\b"), self._date),
            (_rule(r"\bbattery\b"), self._battery),
            (_rule(r"\b(system info|cpu|memory usage|performance)\b"), self._sysinfo),
            (_rule(r"\bscreenshot\b"), self._screenshot),
            (_rule(r"\block (?:the )?(?:screen|computer|pc)\b"), self._lock),
            (_rule(r"\bshut ?down\b"), self._shutdown),
            (_rule(r"\brestart\b|\breboot\b"), self._restart),

            (_rule(r"^open\s+(.+)$", r"^launch\s+(.+)$", r"^start\s+(.+)$"), self._open),
            (_rule(r"^close\s+(.+)$", r"^quit\s+(.+)$", r"^kill\s+(.+)$"), self._close),

            (_rule(r"^search(?: the web)? for (.+)$", r"^google (.+)$"), self._search_web),
            (_rule(r"^(?:search|play)(?:.*on)? youtube(?: for)? (.+)$"), self._search_youtube),
            (_rule(r"^go to (.+)$", r"^open (?:the )?website (.+)$"), self._open_site),

            (_rule(r"^(?:list|show) files? (?:in )?(.*)$"), self._list_dir),
            (_rule(r"^find files? (?:named |called )?(.+?)(?: in (.+))?$"), self._search_files),
            (_rule(r"^create (?:a )?file (?:called |named )?(\S+)(?: with (?:content|text) (.+))?$"), self._create_file),
            (_rule(r"^read (?:the )?file (.+)$"), self._read_file),
            (_rule(r"^delete (?:the )?file (.+)$"), self._delete_file),

            (_rule(r"^remember that (.+?) is (.+)$", r"^remember my (.+?) is (.+)$"), self._remember),
            (_rule(r"^what(?:'s| is) my (.+)\??$"), self._recall),
        ]

    def try_handle(self, text: str):
        """
        Returns a response string if a command matched, else None
        (signalling the caller should fall back to open-ended chat).
        """
        stripped = text.strip()
        for patterns, handler in self.rules:
            for pattern in patterns:
                match = pattern.search(stripped)
                if match:
                    return handler(match)
        return None

    # ------------------------------------------------------------------
    # Handlers
    # ------------------------------------------------------------------
    def _time(self, _match):
        return system.get_time()

    def _date(self, _match):
        return system.get_date()

    def _battery(self, _match):
        return system.get_battery()

    def _sysinfo(self, _match):
        return system.get_system_info()

    def _screenshot(self, _match):
        return system.take_screenshot()

    def _lock(self, _match):
        return system.lock_screen()

    def _shutdown(self, _match):
        return system.shutdown()

    def _restart(self, _match):
        return system.restart()

    def _open(self, match):
        target = match.group(1).strip()
        return apps.open_app(target)

    def _close(self, match):
        target = match.group(1).strip()
        return apps.close_app(target)

    def _search_web(self, match):
        return browser.search_web(match.group(1).strip())

    def _search_youtube(self, match):
        return browser.search_youtube(match.group(1).strip())

    def _open_site(self, match):
        return browser.open_site(match.group(1).strip())

    def _list_dir(self, match):
        path = match.group(1).strip() or "."
        return files.list_dir(path)

    def _search_files(self, match):
        keyword = match.group(1).strip()
        root = (match.group(2) or ".").strip()
        return files.search_files(keyword, root)

    def _create_file(self, match):
        path = match.group(1).strip()
        content = (match.group(2) or "").strip()
        return files.create_file(path, content)

    def _read_file(self, match):
        return files.read_file(match.group(1).strip())

    def _delete_file(self, match):
        return files.delete_file(match.group(1).strip())

    def _remember(self, match):
        key, value = match.group(1).strip(), match.group(2).strip()
        key = re.sub(r"^my\s+", "", key, flags=re.IGNORECASE)
        self.memory.remember_fact(key, value)
        return f"Got it — I'll remember that your {key} is {value}."

    def _recall(self, match):
        key = match.group(1).strip().rstrip("?")
        value = self.memory.recall_fact(key)
        if value:
            return f"Your {key} is {value}."
        return f"I don't have anything remembered for '{key}' yet."
