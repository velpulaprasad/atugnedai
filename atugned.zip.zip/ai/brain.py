"""
ai/brain.py — Central orchestrator.

Flow for every user utterance:
  1. Log it to memory.
  2. Try the rule-based CommandEngine first (deterministic, fast).
  3. If no command matched, fall back to the Chatbot for open-ended reply.
  4. Log the response to memory.
"""

from ai.chatbot import Chatbot
from ai.commands import CommandEngine
from ai.memory import Memory


class Brain:
    def __init__(self, memory: Memory = None):
        self.memory = memory or Memory()
        self.commands = CommandEngine(self.memory)
        self.chatbot = Chatbot(self.memory)

    def process(self, user_text: str) -> str:
        user_text = (user_text or "").strip()
        if not user_text:
            return "I didn't catch that — could you say it again?"

        self.memory.add_conversation("user", user_text)

        response = self.commands.try_handle(user_text)
        if response is None:
            response = self.chatbot.respond(user_text)

        self.memory.add_conversation("jarvis", response)
        return response
