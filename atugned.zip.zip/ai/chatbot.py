"""
ai/chatbot.py — Open-ended conversation fallback.

If ANTHROPIC_API_KEY is configured, conversation is handled by the real
Claude API (with recent history for context). Otherwise this degrades
to a small, honest, pattern-based responder so the app is still usable
offline / without an API key.
"""

import json
import random
import urllib.request
import urllib.error

import config

_GREETINGS = ("hello", "hi", "hey", "good morning", "good evening", "good afternoon")
_THANKS = ("thanks", "thank you", "cheers", "appreciate it")
_FAREWELLS = ("bye", "goodbye", "see you", "exit", "quit")

_FALLBACK_JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs.",
    "I would tell you a UDP joke, but you might not get it.",
    "There are only 10 types of people: those who understand binary and those who don't.",
]


class Chatbot:
    def __init__(self, memory):
        self.memory = memory
        self.use_api = bool(config.ANTHROPIC_API_KEY)

    def respond(self, text: str) -> str:
        if self.use_api:
            reply = self._call_api(text)
            if reply is not None:
                return reply
            # fall through to local responder if the API call failed

        return self._local_reply(text)

    # ------------------------------------------------------------------
    # Anthropic API path
    # ------------------------------------------------------------------
    def _call_api(self, text: str):
        history = self.memory.get_history(limit=config.MAX_HISTORY_MESSAGES)
        messages = []
        for turn in history:
            role = "user" if turn["speaker"] == "user" else "assistant"
            messages.append({"role": role, "content": turn["text"]})
        messages.append({"role": "user", "content": text})

        payload = json.dumps({
            "model": config.ANTHROPIC_MODEL,
            "max_tokens": 500,
            "system": (
                f"You are {config.ASSISTANT_NAME}, a helpful, concise desktop voice "
                "assistant modeled after Jarvis. Keep spoken-aloud replies short "
                "(1-3 sentences) unless the user asks for detail."
            ),
            "messages": messages,
        }).encode("utf-8")

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "x-api-key": config.ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            parts = [block.get("text", "") for block in data.get("content", [])
                     if block.get("type") == "text"]
            reply = "\n".join(p for p in parts if p).strip()
            return reply or None
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError):
            return None

    # ------------------------------------------------------------------
    # Offline fallback path
    # ------------------------------------------------------------------
    def _local_reply(self, text: str) -> str:
        lowered = text.lower().strip()

        if any(lowered.startswith(g) for g in _GREETINGS):
            return f"Hello! I'm {config.ASSISTANT_NAME}. How can I help?"

        if any(word in lowered for word in _THANKS):
            return "You're welcome."

        if any(word in lowered for word in _FAREWELLS):
            return "Goodbye — I'll be here if you need me."

        if "joke" in lowered:
            return random.choice(_FALLBACK_JOKES)

        if "how are you" in lowered:
            return "Running smoothly, thanks for asking. How can I help?"

        if "your name" in lowered:
            return f"I'm {config.ASSISTANT_NAME}, your desktop assistant."

        return (
            "I'm running in offline mode without an API key, so my conversation "
            "is limited. I can still handle commands like opening apps, "
            "searching the web, checking the time, or remembering facts for you. "
            "Set ANTHROPIC_API_KEY for full conversational ability."
        )
