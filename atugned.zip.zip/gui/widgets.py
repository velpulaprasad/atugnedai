"""
gui/widgets.py — Custom Tkinter widgets for a nicer chat UI.

Includes:
  - ChatBubble: a rounded-rectangle message bubble (Canvas-based) for
    either the user or Jarvis, left/right aligned.
  - PulsingIndicator: a small animated circle showing assistant state
    (idle / listening / thinking / speaking).
"""

import tkinter as tk

import config

THEME = config.THEME


class ChatBubble(tk.Frame):
    def __init__(self, parent, text, speaker="jarvis", **kwargs):
        super().__init__(parent, bg=THEME["bg"], **kwargs)
        is_user = speaker == "user"
        bubble_color = THEME["user_bubble"] if is_user else THEME["jarvis_bubble"]
        anchor_side = "e" if is_user else "w"
        label_name = "You" if is_user else config.ASSISTANT_NAME

        container = tk.Frame(self, bg=THEME["bg"])
        container.pack(fill="x", anchor=anchor_side, padx=10, pady=4)

        name_label = tk.Label(
            container, text=label_name, fg=THEME["text_dim"], bg=THEME["bg"],
            font=(THEME["font_family"], 8, "bold"),
        )
        name_label.pack(anchor=anchor_side)

        bubble = tk.Label(
            container,
            text=text,
            fg=THEME["text"],
            bg=bubble_color,
            font=(THEME["font_family"], 10),
            wraplength=460,
            justify="left",
            padx=12,
            pady=8,
        )
        bubble.pack(anchor=anchor_side)


class PulsingIndicator(tk.Canvas):
    """A small circle that pulses to show assistant state."""

    STATE_COLORS = {
        "idle": "#3a4459",
        "listening": "#00e5ff",
        "thinking": "#ffb703",
        "speaking": "#28c76f",
    }

    def __init__(self, parent, size=18, **kwargs):
        super().__init__(parent, width=size, height=size, bg=THEME["bg"],
                          highlightthickness=0, **kwargs)
        self.size = size
        self._state = "idle"
        self._growing = True
        self._radius = size / 2 - 2
        self._min_radius = size / 3
        self._max_radius = size / 2 - 1
        self._circle = self.create_oval(0, 0, size, size, fill=self.STATE_COLORS["idle"],
                                          outline="")
        self._animate()

    def set_state(self, state: str):
        if state in self.STATE_COLORS:
            self._state = state

    def _animate(self):
        color = self.STATE_COLORS.get(self._state, THEME["text_dim"])
        step = 0.4 if self._state != "idle" else 0.0
        if self._growing:
            self._radius += step
            if self._radius >= self._max_radius:
                self._growing = False
        else:
            self._radius -= step
            if self._radius <= self._min_radius:
                self._growing = True

        cx = cy = self.size / 2
        r = self._radius
        self.coords(self._circle, cx - r, cy - r, cx + r, cy + r)
        self.itemconfig(self._circle, fill=color)
        self.after(60, self._animate)
