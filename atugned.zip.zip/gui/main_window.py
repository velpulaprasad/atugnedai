"""
gui/main_window.py — Main application window.

A dark-themed chat interface with:
  - scrollable chat log made of ChatBubble widgets
  - text entry + Send button
  - a mic button that captures one spoken utterance
  - a pulsing status indicator (idle / listening / thinking / speaking)

All slow work (speech recognition, TTS, chatbot/API calls) runs on
background threads; only `self.after(...)` calls touch Tkinter widgets
from the main thread, which is the safe pattern for Tkinter.
"""

import threading
import tkinter as tk
from tkinter import font as tkfont

import config
from ai.brain import Brain
from gui.widgets import ChatBubble, PulsingIndicator
from speech.listen import Listener
from speech.speak import Speaker

THEME = config.THEME


class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(config.WINDOW_TITLE)
        self.geometry(config.WINDOW_SIZE)
        self.configure(bg=THEME["bg"])
        self.minsize(640, 480)

        self.brain = Brain()
        self.speaker = Speaker()
        self.listener = Listener() if config.ENABLE_VOICE_INPUT else None

        self._build_ui()
        self._greet()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        header = tk.Frame(self, bg=THEME["panel"], height=56)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)

        title_font = tkfont.Font(family=THEME["font_family"], size=14, weight="bold")
        tk.Label(
            header, text=f"● {config.ASSISTANT_NAME.upper()}", fg=THEME["accent"],
            bg=THEME["panel"], font=title_font,
        ).pack(side="left", padx=16)

        self.status_label = tk.Label(
            header, text="idle", fg=THEME["text_dim"], bg=THEME["panel"],
            font=(THEME["font_family"], 10),
        )
        self.status_label.pack(side="right", padx=(0, 10))

        self.indicator = PulsingIndicator(header, size=18)
        self.indicator.pack(side="right", padx=(16, 4))

        # Scrollable chat area
        chat_container = tk.Frame(self, bg=THEME["bg"])
        chat_container.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(chat_container, bg=THEME["bg"], highlightthickness=0)
        scrollbar = tk.Scrollbar(chat_container, orient="vertical", command=self.canvas.yview)
        self.chat_frame = tk.Frame(self.canvas, bg=THEME["bg"])

        self.chat_frame.bind(
            "<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas.create_window((0, 0), window=self.chat_frame, anchor="nw", width=880)
        self.canvas.configure(yscrollcommand=scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Input bar
        input_bar = tk.Frame(self, bg=THEME["panel"], height=56)
        input_bar.pack(fill="x", side="bottom")
        input_bar.pack_propagate(False)

        self.entry = tk.Entry(
            input_bar, bg=THEME["user_bubble"], fg=THEME["text"],
            insertbackground=THEME["text"], relief="flat",
            font=(THEME["font_family"], 11),
        )
        self.entry.pack(side="left", fill="both", expand=True, padx=(14, 8), pady=12, ipady=6)
        self.entry.bind("<Return>", lambda e: self._on_send())

        send_btn = tk.Button(
            input_bar, text="Send", command=self._on_send,
            bg=THEME["accent_dim"], fg=THEME["text"], relief="flat",
            activebackground=THEME["accent"], font=(THEME["font_family"], 10, "bold"),
            padx=14,
        )
        send_btn.pack(side="left", padx=(0, 8), pady=12)

        mic_btn = tk.Button(
            input_bar, text="🎙", command=self._on_mic,
            bg=THEME["panel"], fg=THEME["accent"], relief="flat",
            activebackground=THEME["accent_dim"], font=(THEME["font_family"], 14),
            padx=10,
        )
        mic_btn.pack(side="left", padx=(0, 14), pady=12)

        if not self.listener or not self.listener.available:
            mic_btn.configure(state="disabled")
            note = self.listener.error if self.listener else "Voice input disabled in config."
            self._set_status(f"mic unavailable: {note}", "idle")

    # ------------------------------------------------------------------
    # Chat log helpers
    # ------------------------------------------------------------------
    def _add_bubble(self, text, speaker):
        bubble = ChatBubble(self.chat_frame, text, speaker=speaker)
        bubble.pack(fill="x", anchor="e" if speaker == "user" else "w")
        self.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        self.canvas.yview_moveto(1.0)

    def _set_status(self, text, state):
        self.status_label.configure(text=text)
        self.indicator.set_state(state)

    def _greet(self):
        greeting = f"{config.ASSISTANT_NAME} online. How can I help you today?"
        self._add_bubble(greeting, "jarvis")
        self.speaker.speak(greeting)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------
    def _on_send(self):
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, tk.END)
        self._add_bubble(text, "user")
        self._set_status("thinking…", "thinking")
        threading.Thread(target=self._process_and_reply, args=(text,), daemon=True).start()

    def _on_mic(self):
        if not self.listener or not self.listener.available:
            return
        self._set_status("listening…", "listening")
        threading.Thread(target=self._listen_and_reply, daemon=True).start()

    def _listen_and_reply(self):
        text, err = self.listener.listen_once()
        if err:
            self.after(0, self._set_status, "idle", "idle")
            self.after(0, self._add_bubble, err, "jarvis")
            return
        self.after(0, self._add_bubble, text, "user")
        self.after(0, self._set_status, "thinking…", "thinking")
        self._process_and_reply(text)

    def _process_and_reply(self, text):
        response = self.brain.process(text)
        self.after(0, self._deliver_response, response)

    def _deliver_response(self, response):
        self._add_bubble(response, "jarvis")
        self._set_status("speaking…", "speaking")
        self.speaker.speak(response)
        # Return to idle after a short delay (rough estimate, non-blocking).
        self.after(1200, lambda: self._set_status("idle", "idle"))


def run():
    app = MainWindow()
    app.mainloop()
